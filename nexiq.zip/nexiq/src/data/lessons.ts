
export type Lesson = {
  id: string;
  courseId: number;
  title: string;
  isVip: boolean;
  content: string;
};

export const lessons: Lesson[] = [
  {
    id: "programming-intro",
    courseId: 1,
    title: "Ծրագրավորման ներածություն",
    isVip: false,
    content: "Ծրագրավորումը համակարգչին հրահանգներ տալու գործընթացն է։ Այս դասում կծանոթանաս ծրագրավորման հիմունքներին։",
  },
  {
    id: "variables",
    courseId: 1,
    title: "Փոփոխականներ և տվյալների տեսակներ",
    isVip: false,
    content: "Փոփոխականը տվյալ պահելու տեղ է։ Օրինակ՝ const name = 'Անի';։ Տվյալների տեսակներն են տեքստը, թվերը և true/false արժեքները։",
  },
  {
    id: "conditions",
    courseId: 1,
    title: "Պայմաններ և ցիկլեր",
    isVip: true,
    content: "if պայմանը թույլ է տալիս որոշում կայացնել, իսկ ցիկլը՝ կրկնել գործողությունները։ Օրինակ՝ if (age >= 18) ստուգում է տարիքը։",
  },
  {
    id: "practice",
    courseId: 1,
    title: "Գործնական առաջադրանք",
    isVip: true,
    content: "Այս դասում կկիրառես սովորածը՝ ստեղծելով փոքր ծրագրավորման առաջադրանք։",
  },
];
