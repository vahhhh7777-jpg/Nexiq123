
export type LocalizedText = { en: string; hy: string };

export type Lesson = {
  id: string;
  courseId: number;
  title: LocalizedText;
  isVip: boolean;
  content: LocalizedText;
};

const lesson = (
  courseId: number,
  id: string,
  titleEn: string,
  titleHy: string,
  contentEn: string,
  contentHy: string,
  isVip = false,
): Lesson => ({
  id,
  courseId,
  title: { en: titleEn, hy: titleHy },
  content: { en: contentEn, hy: contentHy },
  isVip,
});

export const lessons: Lesson[] = [
  lesson(1, "programming-intro", "Introduction to Programming", "Ծրագրավորման ներածություն",
    "Programming is the practice of writing clear instructions a computer can follow. A program can calculate a total, show a message, or help someone complete a task. Start by describing the problem in plain language, then break the solution into small steps.",
    "Ծրագրավորումը հստակ հրահանգներ գրելու գործընթացն է, որոնց հետևում է համակարգիչը։ Ծրագիրը կարող է հաշվել գումարը, ցուցադրել հաղորդագրություն կամ օգնել լուծել խնդիր։ Սկսիր խնդիրը պարզ բառերով նկարագրելուց, ապա լուծումը բաժանիր փոքր քայլերի։"),
  lesson(1, "variables", "Variables and Data Types", "Փոփոխականներ և տվյալների տեսակներ",
    "A variable gives a useful name to a value. In JavaScript, const learnerName = \"Ani\" stores text, while let lessonsDone = 2 stores a number. Booleans are true or false. Choose names that explain what the value represents.",
    "Փոփոխականը արժեքին տալիս է հասկանալի անուն։ JavaScript-ում const learnerName = \"Անի\" պահում է տեքստ, իսկ let lessonsDone = 2՝ թիվ։ Boolean արժեքը true կամ false է։ Ընտրիր այնպիսի անուններ, որոնք բացատրում են՝ ինչ է պահվում։"),
  lesson(1, "conditions", "Conditions and Loops", "Պայմաններ և ցիկլեր",
    "A condition lets a program choose what to do: if (score >= 10) { ... }. A loop repeats a step while a rule remains true or for each item in a list. Use a loop when the same operation needs to happen several times.",
    "Պայմանը ծրագրին թույլ է տալիս ընտրել գործողությունը․ if (score >= 10) { ... }։ Ցիկլը կրկնում է քայլը, քանի դեռ պայմանը ճիշտ է, կամ ցուցակի յուրաքանչյուր տարրի համար։ Օգտագործիր ցիկլ, երբ նույն գործողությունը պետք է կրկնել։"),
  lesson(1, "practice", "Practical Challenge", "Գործնական առաջադրանք",
    "Practice: create a variable called name, then write a greeting that uses it. Next, add a condition that shows a different message when the learner has completed at least three lessons. Explain what each line does.",
    "Վարժություն․ ստեղծիր name անունով փոփոխական և գրիր այն օգտագործող ողջույն։ Այնուհետև ավելացրու պայման, որը այլ հաղորդագրություն է ցույց տալիս, երբ սովորողն ավարտել է առնվազն երեք դաս։ Բացատրիր յուրաքանչյուր տողի նպատակը։"),

  lesson(2, "ai-basics", "What AI Can and Cannot Do", "Ինչ կարող է և չի կարող անել AI-ն",
    "Artificial intelligence systems find patterns in examples and use them to produce predictions or content. They can help brainstorm, summarize, and explain, but they can also be wrong. Treat AI output as a draft to review, not as an unquestionable source.",
    "Արհեստական բանականության համակարգերը օրինակներում օրինաչափություններ են գտնում և դրանց հիման վրա ստեղծում կանխատեսումներ կամ բովանդակություն։ Դրանք կարող են օգնել գաղափարներ հավաքել, ամփոփել ու բացատրել, բայց կարող են նաև սխալվել։ AI-ի պատասխանը ստուգիր, ոչ թե ընդունիր որպես անվիճելի փաստ։"),
  lesson(2, "ai-prompts", "Writing Useful Prompts", "Օգտակար հարցումների կազմում",
    "A useful prompt includes a goal, relevant context, and the format you need. For example: \"Explain loops to a beginner using a short JavaScript example.\" Add constraints such as length or audience, then refine the request when the first answer misses something.",
    "Օգտակար հարցումը ներառում է նպատակը, անհրաժեշտ համատեքստը և ցանկալի ձևաչափը։ Օրինակ․ «Բացատրիր ցիկլերը սկսնակին՝ JavaScript-ի կարճ օրինակով»։ Ավելացրու սահմանափակումներ՝ ծավալի կամ լսարանի մասին, և ճշգրտիր հարցումը, եթե պատասխանը թերի է։"),
  lesson(2, "ai-review", "Check AI-Generated Answers", "Ստուգիր AI-ի պատասխանները",
    "Before using an AI answer, verify names, dates, calculations, and claims that matter. Ask for sources when appropriate, compare with a trusted reference, and never share private information in a prompt.",
    "AI-ի պատասխանը կիրառելուց առաջ ստուգիր անունները, ամսաթվերը, հաշվարկներն ու կարևոր պնդումները։ Անհրաժեշտության դեպքում խնդրիր աղբյուրներ, համեմատիր վստահելի նյութի հետ և հարցման մեջ երբեք մի ներառիր գաղտնի տեղեկություն։"),
  lesson(2, "ai-project", "Plan a Small AI Project", "Պլանավորիր փոքր AI նախագիծ",
    "Choose one repetitive or information-heavy task. Define who has the problem, what input is available, and what a helpful result looks like. Build a small prototype and evaluate it with real examples before expanding it.",
    "Ընտրիր կրկնվող կամ շատ տեղեկություն պահանջող մեկ խնդիր։ Սահմանիր՝ ում մոտ է խնդիրը, ինչ տվյալներ կան և ինչ արդյունք կլինի օգտակար։ Ստեղծիր փոքր նախատիպ և այն զարգացնելուց առաջ փորձարկիր իրական օրինակներով։"),

  lesson(3, "design-goals", "Design for a Clear Goal", "Նախագծիր հստակ նպատակի համար",
    "Good interface design helps a person complete a task. Identify the audience, their main goal, and the next action they should take. Remove anything that distracts from that action.",
    "Լավ ինտերֆեյսի դիզայնը օգնում է մարդուն կատարել իր խնդիրը։ Սահմանիր լսարանը, նրա հիմնական նպատակը և հաջորդ գործողությունը։ Հեռացրու այն ամենը, ինչը շեղում է այդ քայլից։", true),
  lesson(3, "design-hierarchy", "Visual Hierarchy", "Տեսողական հիերարխիա",
    "Size, spacing, contrast, and alignment guide attention. Give the most important content a clear visual priority, group related information, and keep repeated patterns consistent.",
    "Չափը, տարածությունը, հակադրությունն ու հավասարեցումը ուղղորդում են ուշադրությունը։ Ամենակարևոր բովանդակությանը տուր տեսանելի առաջնահերթություն, խմբավորիր կապված տեղեկությունները և պահպանիր կրկնվող տարրերի նույն ոճը։", true),
  lesson(3, "design-accessibility", "Accessible Interfaces", "Մատչելի ինտերֆեյսներ",
    "Use readable text, sufficient color contrast, labels for controls, and visible keyboard focus. Do not rely on color alone to communicate status. Accessibility makes a product easier for more people to use.",
    "Օգտագործիր ընթեռնելի տեքստ, բավարար գունային հակադրություն, կառավարման տարրերի պիտակներ և ստեղնաշարի տեսանելի ֆոկուս։ Վիճակը մի փոխանցիր միայն գույնով։ Մատչելիությունը արտադրանքը հարմարեցնում է ավելի շատ մարդկանց։", true),
  lesson(3, "design-test", "Test a Screen with Users", "Փորձարկիր էկրանը օգտատերերի հետ",
    "Give a person a realistic task and watch without coaching. Note where they hesitate or misunderstand, then change one thing at a time and test again. Feedback is most useful when tied to observed behavior.",
    "Մարդուն տուր իրական առաջադրանք և հետևիր՝ առանց ուղղորդելու։ Նշիր, թե որտեղ է նա տատանվում կամ սխալ հասկանում, ապա միաժամանակ փոխիր մեկ բան և նորից փորձարկիր։ Հետադարձ կապն առավել օգտակար է, երբ հիմնված է դիտված վարքի վրա։", true),

  lesson(4, "marketing-audience", "Know Your Audience", "Ճանաչիր քո լսարանը",
    "Start with a specific audience and a real need. Learn what they are trying to do, where they look for information, and what would make your offer useful. Avoid trying to speak to everyone at once.",
    "Սկսիր հստակ լսարանից և իրական կարիքից։ Պարզիր՝ մարդիկ ինչ են փորձում անել, որտեղ են տեղեկություն փնտրում և ինչն է առաջարկդ օգտակար դարձնում։ Մի փորձիր միաժամանակ խոսել բոլորի հետ։"),
  lesson(4, "marketing-goals", "Set a Measurable Goal", "Սահմանիր չափելի նպատակ",
    "A useful campaign goal describes an outcome and a time period, such as getting 20 newsletter sign-ups this month. Choose one metric that reflects the goal instead of tracking numbers that do not guide a decision.",
    "Օգտակար արշավի նպատակը նկարագրում է արդյունքն ու ժամանակահատվածը, օրինակ՝ այս ամիս ստանալ 20 գրանցում տեղեկագրին։ Ընտրիր նպատակը արտացոլող մեկ չափանիշ՝ անորոշ թվեր հետևելու փոխարեն։"),
  lesson(4, "marketing-content", "Create Helpful Content", "Ստեղծիր օգտակար բովանդակություն",
    "Make content that answers a question, solves a small problem, or helps the audience make a decision. Match the format and channel to how people prefer to learn, and include one clear next step.",
    "Ստեղծիր բովանդակություն, որը պատասխանում է հարցի, լուծում փոքր խնդիր կամ օգնում որոշում կայացնել։ Ձևաչափն ու հարթակը համապատասխանեցրու մարդկանց սովորելու ձևին և ավելացրու մեկ հստակ հաջորդ քայլ։"),
  lesson(4, "marketing-review", "Review and Improve a Campaign", "Վերլուծիր և բարելավիր արշավը",
    "Compare results with the goal you set. Look for a useful pattern, write down what you learned, and test one change in the next campaign. A small, measured experiment is more informative than changing everything at once.",
    "Համեմատիր արդյունքները սահմանած նպատակի հետ։ Գտիր օգտակար օրինաչափություն, գրանցիր սովորածը և հաջորդ արշավում փորձարկիր մեկ փոփոխություն։ Փոքր, չափվող փորձն ավելի շատ բան է ցույց տալիս, քան ամեն ինչ միանգամից փոխելը։"),

  lesson(5, "video-story", "Plan a Short Video", "Պլանավորիր կարճ տեսանյութ",
    "A short video still needs a beginning, a clear central idea, and an ending. Write down the viewer, the one thing they should remember, and a simple sequence of shots before recording.",
    "Կարճ տեսանյութն էլ պետք է ունենա սկիզբ, հստակ հիմնական միտք և ավարտ։ Նկարահանումից առաջ գրիր՝ ով է դիտողը, ինչ պետք է հիշի և ինչ կադրերի պարզ հերթականություն է պետք։", true),
  lesson(5, "video-framing", "Framing and Light", "Կադրավորում և լուսավորություն",
    "Keep the subject easy to see, leave intentional space in the frame, and use steady light. Check the background and record a short test clip before filming the full scene.",
    "Առարկան պահիր հստակ տեսանելի, կադրում թող նպատակային ազատ տարածք և օգտագործիր կայուն լուսավորություն։ Ստուգիր ֆոնը և ամբողջ տեսարանը նկարահանելուց առաջ փորձնական կարճ տեսանյութ արա։", true),
  lesson(5, "video-audio", "Record Clear Audio", "Ձայնագրիր հստակ ձայն",
    "Viewers may tolerate simple visuals, but unclear audio is hard to follow. Reduce background noise, keep the microphone close, and listen to a test recording with headphones.",
    "Դիտողները կարող են ընդունել պարզ պատկերը, բայց անհասկանալի ձայնին հետևելը դժվար է։ Նվազեցրու ֆոնային աղմուկը, խոսափողը պահիր մոտ և ականջակալով լսիր փորձնական ձայնագրությունը։", true),
  lesson(5, "video-edit", "Edit with Intention", "Մոնտաժիր նպատակային",
    "Remove pauses that do not add meaning, arrange clips so the idea is easy to follow, and keep on-screen text readable. Review the video once for story and once for technical issues.",
    "Հեռացրու իմաստ չավելացնող դադարները, դասավորիր կադրերը այնպես, որ միտքը հասկանալի լինի, և պահիր էկրանի տեքստը ընթեռնելի։ Տեսանյութը մեկ անգամ դիտիր պատմության, մեկ անգամ՝ տեխնիկական սխալների համար։", true),

  lesson(6, "web-structure", "How Web Pages Are Built", "Ինչպես են կառուցվում վեբ էջերը",
    "HTML describes the structure and meaning of page content. CSS controls its appearance, and JavaScript can respond to user actions. Keeping these responsibilities clear makes a site easier to understand and maintain.",
    "HTML-ը նկարագրում է էջի կառուցվածքն ու բովանդակության իմաստը։ CSS-ը կառավարում է տեսքը, իսկ JavaScript-ը կարող է արձագանքել գործողություններին։ Այս պատասխանատվությունների տարանջատումը հեշտացնում է կայքի զարգացումն ու պահպանումը։", true),
  lesson(6, "web-semantic-html", "Semantic HTML", "Իմաստային HTML",
    "Choose elements by meaning: use a main region for primary content, headings in order, and buttons for actions. Semantic structure improves accessibility and makes code easier for other developers to scan.",
    "Ընտրիր տարրերը ըստ իմաստի․ հիմնական բովանդակության համար օգտագործիր main, վերնագրերը պահիր հերթականությամբ, գործողությունների համար՝ button։ Իմաստային կառուցվածքը բարելավում է մատչելիությունն ու կոդի ընթեռնելիությունը։", true),
  lesson(6, "web-css-layout", "Responsive CSS Layouts", "Հարմարեցվող CSS դասավորություններ",
    "Use flexible units and layout tools such as Flexbox or Grid so content can adapt to different screens. Test narrow and wide viewports, and keep tap targets and text comfortable on mobile.",
    "Օգտագործիր ճկուն միավորներ և Flexbox կամ Grid գործիքներ, որպեսզի բովանդակությունը հարմարվի տարբեր էկրաններին։ Փորձարկիր նեղ և լայն չափերը, իսկ բջջայինի համար պահիր հարմար կոճակներ ու ընթեռնելի տեքստ։", true),
  lesson(6, "web-debugging", "Debug and Publish Safely", "Ստուգիր և ապահով հրապարակիր",
    "Reproduce a problem, read the browser console, and change one likely cause at a time. Before publishing, check links, keyboard access, mobile layout, and that no secret keys are included in client-side code.",
    "Վերարտադրիր խնդիրը, կարդա բրաուզերի վահանակը և միաժամանակ ստուգիր մեկ հավանական պատճառ։ Հրապարակելուց առաջ ստուգիր հղումները, ստեղնաշարով հասանելիությունը, բջջային դասավորությունն ու համոզվիր, որ գաղտնի բանալիներ չկան հաճախորդային կոդում։", true),
];

export const getLessonsForCourse = (courseId: number) =>
  lessons.filter((item) => item.courseId === courseId);
