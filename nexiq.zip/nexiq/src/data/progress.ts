
import { lessons } from "./lessons";

const STORAGE_KEY = "nexiq-completed-lessons";
const validLessonIds = new Set(lessons.map((lesson) => lesson.id));

export function readStoredJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;

  try {
    const saved = window.localStorage.getItem(key);
    return saved ? (JSON.parse(saved) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeStoredJson(key: string, value: unknown): boolean {
  if (typeof window === "undefined") return false;

  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function getCompletedLessons(): string[] {
  const parsed = readStoredJson<unknown>(STORAGE_KEY, []);

  if (Array.isArray(parsed)) {
    return [...new Set(parsed.filter(
      (id): id is string => typeof id === "string" && validLessonIds.has(id),
    ))];
  }

  // Migrate the older courseId -> lesson indexes format without losing progress.
  if (parsed && typeof parsed === "object") {
    const migrated = Object.entries(parsed as Record<string, unknown>)
      .flatMap(([courseId, indexes]) => {
        if (!Array.isArray(indexes)) return [];
        const courseLessons = lessons.filter(
          (lesson) => lesson.courseId === Number(courseId),
        );
        return indexes.flatMap((index) =>
          Number.isInteger(index) && courseLessons[index as number]
            ? [courseLessons[index as number].id]
            : [],
        );
      });
    const uniqueMigrated = [...new Set(migrated)];
    writeStoredJson(STORAGE_KEY, uniqueMigrated);
    return uniqueMigrated;
  }

  return [];
}

export function completeLesson(lessonId: string): boolean {
  if (!validLessonIds.has(lessonId)) return false;
  const completed = getCompletedLessons();
  if (completed.includes(lessonId)) return false;
  return writeStoredJson(STORAGE_KEY, [...completed, lessonId]);
}
