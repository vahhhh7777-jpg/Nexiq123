
const STORAGE_KEY = "nexiq-completed-lessons";

export function getCompletedLessons(): string[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = saved ? JSON.parse(saved) : [];

    return Array.isArray(parsed)
      ? parsed.filter((id): id is string => typeof id === "string")
      : [];
  } catch {
    return [];
  }
}

export function completeLesson(lessonId: string): void {
  const completed = getCompletedLessons();

  if (!completed.includes(lessonId)) {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify([...completed, lessonId])
    );
  }
}
