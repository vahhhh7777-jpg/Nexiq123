import { BrowserRouter, Routes, Route } from "react-router-dom";
import LessonPage from "./pages/LessonPage";
import {
  completeLesson,
  getCompletedLessons,
  readStoredJson,
  writeStoredJson,
} from "./data/progress";
import { getLessonsForCourse } from "./data/lessons";
import {
  Children,
  cloneElement,
  Fragment,
  isValidElement,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Bot,
  Check,
  ChevronRight,
  Code2,
  Crown,
  Flame,
  Globe,
  GraduationCap,
  LayoutDashboard,
  LockKeyhole,
  Menu,
  MessageCircle,
  Palette,
  Play,
  Search,
  Send,
  Settings,
  Sparkles,
  Target,
  Trophy,
  UserRound,
  Video,
  X,
  Zap,
  Megaphone,
} from "lucide-react";
import {
  translations,
  type Language,
  type TranslationKey,
} from "./translations";

type Page =
  | "dashboard"
  | "courses"
  | "challenges"
  | "aiTutor"
  | "achievements"
  | "vip"
  | "profile"
  | "settings";

type Course = {
  id: number;
  title: string;
  description: string;
  category: string;
  icon: typeof Code2;
  color: string;
  lessons: number;
  duration: string;
  xp: number;
  vip: boolean;
};

type LearnerProfile = { name: string; goal: string };
type ChatMessage = { id: number; role: "user" | "assistant"; text: string };

const challengeIds = ["html-link", "js-const", "ux-goal"];

const initialCourses: Course[] = [
  {
    id: 1,
    title: "Programming Fundamentals",
    description: "Build your first programming skills, one step at a time.",
    category: "Programming",
    icon: Code2,
    color: "orange",
    lessons: 4,
    duration: "3 hours",
    xp: 100,
    vip: false,
  },
  {
    id: 2,
    title: "AI Tools & Productivity",
    description: "Discover how AI can help you learn and create faster.",
    category: "Artificial Intelligence",
    icon: Bot,
    color: "purple",
    lessons: 4,
    duration: "2.5 hours",
    xp: 100,
    vip: false,
  },
  {
    id: 3,
    title: "UI/UX Design",
    description: "Learn the foundations of beautiful digital experiences.",
    category: "UI/UX Design",
    icon: Palette,
    color: "pink",
    lessons: 4,
    duration: "4 hours",
    xp: 100,
    vip: true,
  },
  {
    id: 4,
    title: "Social Media Marketing",
    description: "Create content and understand digital audiences.",
    category: "Digital Marketing",
    icon: Megaphone,
    color: "blue",
    lessons: 4,
    duration: "2 hours",
    xp: 100,
    vip: false,
  },
  {
    id: 5,
    title: "Video Production",
    description: "Turn your ideas into engaging videos.",
    category: "Video Production",
    icon: Video,
    color: "green",
    lessons: 4,
    duration: "3.5 hours",
    xp: 100,
    vip: true,
  },
  {
    id: 6,
    title: "Web Development Essentials",
    description: "Learn how to structure, style, and safely publish web pages.",
    category: "Web Development",
    icon: Globe,
    color: "orange",
    lessons: 4,
    duration: "5 hours",
    xp: 100,
    vip: true,
  },
];

const categories = [
  "All",
  "Programming",
  "Artificial Intelligence",
  "UI/UX Design",
  "Digital Marketing",
  "Video Production",
  "Web Development",
];

const pageIcons: Record<Page, typeof LayoutDashboard> = {
  dashboard: LayoutDashboard,
  courses: BookOpen,
  challenges: Target,
  aiTutor: Bot,
  achievements: Trophy,
  vip: Crown,
  profile: UserRound,
  settings: Settings,
};

const pageLabels: Record<Page, string> = {
  dashboard: "Dashboard",
  courses: "Courses",
  challenges: "Challenges",
  aiTutor: "AI Tutor",
  achievements: "Achievements",
  vip: "Nexiq VIP",
  profile: "My Profile",
  settings: "Settings",
};

function translatedCourseTitle(
  course: Course,
  language: Language,
): string {
  if (language !== "hy") return course.title;

  const titles: Record<number, string> = {
    1: "Ծրագրավորման հիմունքներ",
    2: "AI գործիքներ և արդյունավետություն",
    3: "UI/UX դիզայն",
    4: "Սոցիալական մեդիա մարքեթինգ",
    5: "Վիդեոարտադրություն",
    6: "Վեբ ծրագրավորման հիմունքներ",
  };

  return titles[course.id] ?? course.title;
}

function translatedCourseDescription(course: Course, language: Language) {
  if (language === "en") return course.description;
  const descriptions: Record<number, string> = {
    1: "Սովորիր ծրագրավորման հիմունքները՝ քայլ առ քայլ։",
    2: "Բացահայտիր, թե ինչպես են AI գործիքներն օգնում սովորել և ստեղծել։",
    3: "Սովորիր թվային փորձառությունների դիզայնի հիմունքները։",
    4: "Ճանաչիր լսարանդ և ստեղծիր օգտակար թվային բովանդակություն։",
    5: "Գաղափարներդ վերածիր հստակ ու ներգրավող տեսանյութերի։",
    6: "Սովորիր կառուցել, ձևավորել և ապահով հրապարակել վեբ էջեր։",
  };
  return descriptions[course.id] ?? course.description;
}

function translatedCategory(category: string, language: Language) {
  if (language === "en") return category;
  const categoriesHy: Record<string, string> = {
    All: "Բոլորը",
    Programming: "Ծրագրավորում",
    "Artificial Intelligence": "Արհեստական բանականություն",
    "UI/UX Design": "UI/UX դիզայն",
    "Digital Marketing": "Թվային մարքեթինգ",
    "Video Production": "Տեսանյութերի ստեղծում",
    "Web Development": "Վեբ ծրագրավորում",
  };
  return categoriesHy[category] ?? category;
}
const armenianText: Record<string, string> = {
  "Dashboard": "Գլխավոր",
  "Courses": "Դասընթացներ",
  "Challenges": "Մարտահրավերներ",
  "AI Tutor": "AI օգնական",
  "Achievements": "Նվաճումներ",
  "My Profile": "Իմ հաշիվը",
  "Settings": "Կարգավորումներ",
  "Home": "Գլխավոր",
  "Quests": "Առաջադրանքներ",
  "Profile": "Պրոֆիլ",


  "Programming Fundamentals": "Ծրագրավորման հիմունքներ",
  "Build your first programming skills, one step at a time.": "Սովորիր ծրագրավորման հիմունքները՝ քայլ առ քայլ։",
  "AI Tools & Productivity": "AI գործիքներ և արդյունավետություն",
  "Discover how AI can help you learn and create faster.": "Բացահայտիր, թե ինչպես կարող է AI-ն օգնել քեզ ավելի արագ սովորել և ստեղծագործել։",
  "UI/UX Design": "UI/UX դիզայն",
  "Learn the foundations of beautiful digital experiences.": "Սովորիր գեղեցիկ թվային փորձառություններ ստեղծելու հիմունքները։",
  "Social Media Marketing": "Սոցիալական մեդիայի մարքեթինգ",
  "Create content and understand digital audiences.": "Ստեղծիր բովանդակություն և հասկացիր թվային լսարանի կարիքները։",
  "Video Production": "Տեսանյութերի ստեղծում",
  "Turn your ideas into engaging videos.": "Գաղափարներդ վերածիր հետաքրքիր տեսանյութերի։",
  "Advanced Web Development": "Վեբ ծրագրավորման առաջադեմ դասընթաց",
  "Explore modern tools for building websites.": "Բացահայտիր կայքեր ստեղծելու ժամանակակից գործիքները։",
  "All": "Բոլորը",
  "3 hours": "3 ժամ",
  "2.5 hours": "2.5 ժամ",
  "4 hours": "4 ժամ",
  "2 hours": "2 ժամ",
  "3.5 hours": "3.5 ժամ",
  "5 hours": "5 ժամ",


  "YOUR NEXT LEVEL STARTS HERE": "ՔՈ ՀԱՋՈՐԴ ՄԱԿԱՐԴԱԿԸ ՍԿՍՎՈՒՄ Է ԱՅՍՏԵՂ",
  "Learn smarter.": "Սովորիր ավելի խելացի։",
  "Become unstoppable.": "Շարունակիր զարգանալ։",
  "Build real-world skills, complete challenges, and turn your progress into achievements.":
    "Զարգացրու գործնական հմտություններդ, կատարիր առաջադրանքներ և հասիր նոր նվաճումների։",
  "Explore courses": "Բացահայտել դասընթացները",
  "Daily challenge": "Օրվա մարտահրավեր",
  "Total earned": "Ընդհանուր վաստակ",
  "Rising learner": "Զարգացող սովորող",
  "Total XP": "Ընդհանուր XP",
  "Keep moving forward": "Շարունակիր առաջ շարժվել",
  "My courses": "Իմ դասընթացները",
  "Learning in progress": "Ընթացիկ ուսուցում",
  "Day streak": "Անընդմեջ օրեր",
  "3 days": "3 օր",
  "Consistency wins": "Կանոնավորությունն արդյունք է տալիս",
  "Keep growing, one step at a time.": "Զարգացիր՝ մեկ քայլով։",

  "YOUR JOURNEY": "ՔՈ ՈՒՂԻՆ",
  "Level 4 — Rising Learner": "Մակարդակ 4 — Զարգացող սովորող",
  "Every lesson takes you further.": "Յուրաքանչյուր դաս քեզ առաջ է տանում։",
  "XP to next level": "XP մինչև հաջորդ մակարդակ",
  "HANDPICKED FOR YOU": "ԸՆՏՐՎԱԾ ՔԵԶ ՀԱՄԱՐ",
  "Featured courses": "Ընտրված դասընթացներ",
  "Skills worth investing your time in.": "Հմտություններ, որոնց վրա արժե ժամանակ տրամադրել։",
  "View all": "Դիտել բոլորը",
  "DAILY QUEST": "ՕՐՎԱ ԱՌԱՋԱԴՐԱՆՔ",
  "Small steps. Big progress.": "Փոքր քայլեր։ Մեծ առաջընթաց։",
  "Complete daily tasks and earn XP while building your skills.":
    "Կատարիր ամենօրյա առաջադրանքներ, վաստակիր XP և զարգացրու հմտություններդ։",
  "View challenges": "Դիտել առաջադրանքները",
  "YOUR AI COMPANION": "ՔՈ AI ՕԳՆԱԿԱՆԸ",
  "Questions welcome.": "Հարցերդ ողջունելի են։",
  "Explore ideas, clarify concepts, and keep your curiosity alive.":
    "Բացահայտիր գաղափարներ, հասկացիր բարդ թեմաները և պահպանիր հետաքրքրասիրությունդ։",
  "Meet AI Tutor": "Ծանոթանալ AI օգնականին",
  "GO BEYOND THE BASICS": "ԱՆՑԻՐ ՀԻՄՈՒՆՔՆԵՐԻՑ ԱՅՆ ԿՈՂՄ",
  "Unlock your full potential.": "Բացահայտիր քո ամբողջ ներուժը։",
  "Discover exclusive courses and a more powerful learning journey.":
    "Բացահայտիր հատուկ դասընթացներ և զարգացիր նոր մակարդակում։",
  "Discover VIP": "Բացահայտել VIP-ը",

  "YOUR LEARNING LIBRARY": "ՔՈ ՈՒՍՈՒՄՆԱԿԱՆ ԳՐԱԴԱՐԱՆԸ",
  "Find your next skill and learn at your own pace.":
    "Գտիր հաջորդ հմտությունդ և սովորիր քեզ հարմար տեմպով։",
  "Search courses...": "Փնտրել դասընթաց...",
  "Programming": "Ծրագրավորում",
  "Artificial Intelligence": "Արհեստական բանականություն",
  "Design": "Դիզայն",
  "Marketing": "Մարքեթինգ",
  "Creative": "Ստեղծագործական",
  "No courses found": "Դասընթացներ չեն գտնվել",
  "Try a different search or category.":
    "Փորձիր որոնման այլ բառ կամ բաժին։",
  "Clear filters": "Մաքրել ֆիլտրերը",
  "Back to courses": "Վերադառնալ դասընթացներին",
  "LEARN SOMETHING NEW": "ՍՈՎՈՐԻՐ ՆՈՐ ԲԱՆ",
  "COURSE CONTENT": "ԴԱՍԸՆԹԱՑԻ ԲՈՎԱՆԴԱԿՈՒԹՅՈՒՆԸ",
  "Your learning path": "Քո ուսումնական ուղին",
  "Introduction and key concepts": "Ներածություն և հիմնական գաղափարներ",
  "Understand the fundamentals": "Հասկացիր հիմունքները",
  "Practice with a guided example": "Փորձիր օրինակով",
  "Test your knowledge": "Ստուգիր գիտելիքներդ",
  "Start learning": "Սկսել սովորել",

  "DAILY QUESTS": "ԱՄԵՆՕՐՅԱ ԱՌԱՋԱԴՐԱՆՔՆԵՐ",
  "Challenge yourself": "Մարտահրավեր նետիր քեզ",
  "Build a learning habit with small, achievable actions.":
    "Սովորելու սովորություն ձևավորիր փոքր ու իրագործելի քայլերով։",
  "TODAY'S MISSION": "ԱՅՍՕՐՎԱ ԱՌԱՋԱԴՐԱՆՔԸ",
  "Progress over perfection.": "Կարևորը առաջընթացն է։",
  "Complete your tasks and collect bonus XP.":
    "Կատարիր առաջադրանքները և վաստակիր լրացուցիչ XP։",
  "Today's progress": "Այսօրվա առաջընթացը",
  "Learn something new": "Սովորիր նոր բան",
  "Spend 10 minutes exploring a new topic.":
    "10 րոպե տրամադրիր նոր թեմա ուսումնասիրելուն։",
  "Ask a great question": "Տուր հետաքրքիր հարց",
  "Use your curiosity to explore an idea.":
    "Հետաքրքրասիրությամբդ բացահայտիր նոր գաղափար։",
  "Think like a creator": "Մտածիր ստեղծագործողի պես",
  "Write down one idea for a project.":
    "Գրի առ մեկ գաղափար նախագծի համար։",
  "Complete": "Կատարել",

  "YOUR PERSONAL LEARNING COMPANION": "ՔՈ ԱՆՁՆԱԿԱՆ ՈՒՍՈՒՄՆԱԿԱՆ ՕԳՆԱԿԱՆԸ",
  "Ask questions, explore ideas, and make difficult topics easier.":
    "Տուր հարցեր, ուսումնասիրիր գաղափարներ և ավելի հեշտ հասկացիր բարդ թեմաները։",
  "Learning assistant demo": "Ուսումնական օգնականի ցուցադրական տարբերակ",
  "Hey, learner!": "Ողջո՛ւյն, սովորո՛ղ։",
  "I'm here to help you understand new concepts. Ask me about programming, design, AI, or anything you're learning.":
    "Ես այստեղ եմ՝ նոր գաղափարները հասկանալուդ օգնելու համար։ Հարցրու ծրագրավորման, դիզայնի, AI-ի կամ քո սովորած ցանկացած թեմայի մասին։",
  "Ask your learning question...": "Գրիր ուսումնական հարցդ...",
  "Questions asked in this session": "Այս ընթացքում տրված հարցերը",
  "Explain a concept": "Բացատրել գաղափարը",
  "Break down a difficult idea into simple steps.":
    "Բարդ գաղափարը բաժանել պարզ քայլերի։",
  "Practice a skill": "Վարժվել հմտության մեջ",
  "Try examples and strengthen your understanding.":
    "Փորձել օրինակներ և ամրապնդել գիտելիքները։",

  "YOUR MILESTONES": "ՔՈ ՆՎԱՃՈՒՄՆԵՐԸ",
  "Every small win is a step toward something bigger.":
    "Յուրաքանչյուր փոքր հաջողություն քայլ է դեպի մեծ նպատակը։",
  "COLLECTION PROGRESS": "ՆՎԱՃՈՒՄՆԵՐԻ ԱՌԱՋԸՆԹԱՑԸ",
  "First Steps": "Առաջին քայլերը",
  "Start your learning journey.": "Սկսիր քո ուսումնական ուղին։",
  "Curious Mind": "Հետաքրքրասեր միտք",
  "Explore your first course.": "Բացահայտիր առաջին դասընթացդ։",
  "Quest Starter": "Առաջադրանքի մեկնարկ",
  "Complete your first challenge.": "Կատարիր առաջին մարտահրավերդ։",
  "XP Collector": "XP հավաքող",
  "Earn 500 XP.": "Վաստակիր 500 XP։",
  "Consistent Learner": "Հետևողական սովորող",
  "Keep your learning streak alive.": "Շարունակիր սովորել ամեն օր։",
  "VIP Explorer": "VIP հետազոտող",
  "Discover the VIP learning path.": "Բացահայտիր VIP ուսումնական ուղին։",
  "UNLOCKED": "ԲԱՑՎԱԾ Է",

  "THE NEXT LEVEL": "ՀԱՋՈՐԴ ՄԱԿԱՐԴԱԿԸ",
  "Explore the possibilities of a more advanced learning experience.":
    "Բացահայտիր ավելի առաջադեմ ուսուցման հնարավորությունները։",
  "More skills. More possibilities.": "Ավելի շատ հմտություններ։ Ավելի շատ հնարավորություններ։",
  "Exclusive courses": "Հատուկ դասընթացներ",
  "Explore advanced learning paths.": "Բացահայտիր առաջադեմ ուսումնական ուղիները։",
  "Deeper learning": "Ավելի խոր ուսուցում",
  "Build on your skills with focused lessons.":
    "Զարգացրու հմտություններդ նպատակային դասերով։",
  "More challenges": "Ավելի շատ առաջադրանքներ",
  "Discover additional ways to practice.":
    "Բացահայտիր վարժվելու նոր եղանակներ։",
  "Learning milestones": "Ուսումնական նվաճումներ",
  "Keep track of your progress.": "Հետևիր քո առաջընթացին։",

  "YOUR PERSONAL SPACE": "ՔՈ ԱՆՁՆԱԿԱՆ ՏԱՐԱԾՔԸ",
  "Your learning identity and progress, all in one place.":
    "Քո ուսումնական տվյալներն ու առաջընթացը՝ մեկ տեղում։",
  "Future Creator": "Ապագա ստեղծող",
  "Nexiq learner since today": "Nexiq-ի սովորող՝ այսօրվանից",
  "Courses started": "Սկսած դասընթացներ",
  "YOUR LEARNING": "ՔՈ ՈՒՍՈՒՑՈՒՄԸ",
  "Continue your journey": "Շարունակիր քո ուղին",
  "Account preferences": "Հաշվի կարգավորումներ",
  "Manage your app settings": "Կառավարիր հավելվածի կարգավորումները",

  "MAKE IT YOURS": "ԿԱՐԳԱՎՈՐԻՐ ՔԵԶ ՀԱՄԱՐ",
  "Choose how Nexiq works for you.": "Ընտրիր, թե ինչպես աշխատի Nexiq-ը քեզ համար։",
  "App language": "Հավելվածի լեզուն",
  "Choose your preferred language.": "Ընտրիր նախընտրած լեզուդ։",
  "Learning experience": "Ուսուցման փորձառություն",
  "Personalized recommendations are in demo mode.":
    "Անհատական առաջարկներն առայժմ ցուցադրական ռեժիմում են։",
  "Privacy and security": "Գաղտնիություն և անվտանգություն",
  "Authentication and account controls will be added later.":
    "Մուտքի և հաշվի կառավարման գործիքները կավելացվեն ավելի ուշ։",
  "AI responses are currently simulated.":
    "AI պատասխաններն առայժմ ցուցադրական են։",
  "Open": "Բացել",
  "WORKSPACE": "ԱՇԽԱՏԱՆՔԱՅԻՆ ՏԱՐԱԾՔ",
  "YOUR ACCOUNT": "ՔՈ ՀԱՇԻՎԸ",
  "Unlock Nexiq VIP": "Բացահայտիր Nexiq VIP-ը",
  "Take your skills further": "Զարգացրու հմտություններդ",
  "LANGUAGE": "ԼԵԶՈՒ",
  "WELCOME BACK": "ԲԱՐԻ ԳԱԼՈՒՍՏ",
  "Ready to evolve?": "Պատրա՞ստ ես զարգանալու",
  "Web Development Essentials": "Վեբ ծրագրավորման հիմունքներ",
  "Explore VIP": "Բացահայտել VIP-ը",
  "Review course": "Դիտել դասընթացը",
  "Challenges completed": "Ավարտված մարտահրավերներ",
  "PRACTICE CHALLENGES": "ԳՈՐԾՆԱԿԱՆ ՄԱՐՏԱՀՐԱՎԵՐՆԵՐ",
  "PRACTICE SET": "ԳՈՐԾՆԱԿԱՆ ԱՌԱՋԱԴՐԱՆՔՆԵՐ",
  "Learn, test, and earn XP.": "Սովորիր, ստուգիր գիտելիքներդ և վաստակիր XP։",
  "Correct answers earn XP. You can retry any question.":
    "Ճիշտ պատասխանները XP են բերում։ Կարող ես կրկին փորձել։",
  "Challenge progress": "Մարտահրավերների առաջընթացը",
  "Answer beginner-friendly questions to check your understanding and earn XP.":
    "Պատասխանիր սկսնակների հարցերին, ստուգիր գիտելիքներդ և վաստակիր XP։",
  "Out of 12 available free lessons": "Անվճար հասանելի 12 դասից",
  "Progress across lessons available in the free demo":
    "Անվճար ցուցադրական տարբերակում հասանելի դասերի առաջընթացը",
  "HTML link element": "HTML հղման տարրը",
  "Which HTML element creates a hyperlink? Enter the element name without angle brackets.":
    "HTML-ի ո՞ր տարրն է ստեղծում հղում։ Գրիր տարրի անունը՝ առանց անկյունային փակագծերի։",
  "JavaScript constants": "JavaScript-ի հաստատուններ",
  "Which JavaScript keyword declares a block-scoped constant?":
    "JavaScript-ի ո՞ր բանալի բառն է հայտարարում բլոկի շրջանակում հաստատուն։",
  "UX fundamentals": "UX-ի հիմունքներ",
  "UX is short for user experience or user interface? Enter the missing word.":
    "UX-ը user experience-ի՞, թե՞ user interface-ի հապավումն է։ Գրիր բաց թողնված բառը։",
  "Check answer": "Ստուգել պատասխանը",
  "Not quite. Review the question and try again.":
    "Դեռ ճիշտ չէ։ Կրկին կարդա հարցը և փորձիր նորից։",
  "Correct answer.": "Ճիշտ պատասխան։",
  "Complete every lesson in a free course.": "Ավարտիր անվճար դասընթացի բոլոր դասերը։",
  "Complete five lessons.": "Ավարտիր հինգ դաս։",
  "Complete all three practice challenges.": "Ավարտիր բոլոր երեք գործնական մարտահրավերները։",
  "Earn 500 XP from lessons and challenges.": "Դասերով և մարտահրավերներով վաստակիր 500 XP։",
  "Course Finisher": "Դասընթացն ավարտող",
  "Five Lessons": "Հինգ դաս",
  "Challenge Set": "Մարտահրավերների շարք",
  "This profile is stored in this browser.":
    "Այս պրոֆիլը պահպանվում է այս բրաուզերում։",
  "Your learning activity will appear here": "Քո ուսումնական ակտիվությունն այստեղ կհայտնվի։",
  "Start a free course. Your progress is saved in this browser.":
    "Սկսիր անվճար դասընթաց։ Առաջընթացը պահպանվում է այս բրաուզերում։",
  "Completed lesson": "Ավարտված դաս",
  "No lessons completed yet.": "Ավարտված դասեր դեռ չկան։",
  "Local profile in this browser": "Տեղային պրոֆիլ՝ այս բրաուզերում",
  "Demo mode: responses are generated locally.":
    "Ցուցադրական ռեժիմ․ պատասխանները ստեղծվում են տեղային։",
  "A real AI API can be connected later.":
    "Հետագայում կարելի է միացնել իրական AI API։",
  "Membership and payments are not enabled in this demo.":
    "Այս ցուցադրական տարբերակում անդամակցությունն ու վճարումները միացված չեն։",
  "This is a preview only. Real VIP access, subscriptions, and payments must be connected securely on the backend.":
    "Սա միայն նախադիտում է։ Իրական VIP մուտքը, բաժանորդագրություններն ու վճարումները պետք է ապահով միացվեն սերվերում։",
  "These fields are saved only in this browser.":
    "Այս դաշտերը պահպանվում են միայն այս բրաուզերում։",
};

function LocalizedUI({
  language,
  children,
}: {
  language: Language;
  children: ReactNode;
}) {
  const translateNode = (node: ReactNode): ReactNode => {
    if (typeof node === "string") {
      if (language !== "hy") return node;

      const trimmed = node.trim();
      const translated = armenianText[trimmed];

      return translated
        ? node.replace(trimmed, translated)
        : node;
    }

    if (Array.isArray(node)) {
      return Children.map(node, translateNode);
    }

if (isValidElement<{ children?: ReactNode; placeholder?: string; "aria-label"?: string; title?: string }>(node)) {
  const props = node.props;

  const translatedChildren = translateNode(props.children);

  if (node.type === Fragment) {
    return (
      <Fragment>
        {translatedChildren}
      </Fragment>
    );
  }

  const translateAttribute = (value?: string) =>
    language === "hy" && value
      ? armenianText[value] ?? value
      : value;

  return cloneElement(node, {
    ...props,
    placeholder: translateAttribute(props.placeholder),
    "aria-label": translateAttribute(props["aria-label"]),
    title: translateAttribute(props.title),
  }, translatedChildren);
}

return node;

  };

  return <>{translateNode(children)}</>;
}
function App() {
  const [completedLessons, setCompletedLessons] = useState<string[]>(
    () => getCompletedLessons(),
  );
  const [language, setLanguage] = useState<Language>(() => {
    const saved = readStoredJson<unknown>("nexiq-language", "hy");
    return saved === "en" || saved === "hy" ? saved : "hy";
  });
  const [page, setPage] = useState<Page>("dashboard");
  const [menuOpen, setMenuOpen] = useState(false);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [activeLessonIndex, setActiveLessonIndex] = useState(0);
  const [notice, setNotice] = useState("");
  const [question, setQuestion] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [completedChallenges, setCompletedChallenges] = useState<string[]>(() => {
    const saved = readStoredJson<unknown>("nexiq-completed-challenges", []);
    return Array.isArray(saved)
      ? [...new Set(saved.filter(
          (id): id is string =>
            typeof id === "string" && challengeIds.includes(id),
        ))]
      : [];
  });
  const [challengeAnswers, setChallengeAnswers] = useState<Record<string, string>>({});
  const [challengeFeedback, setChallengeFeedback] = useState<
    Record<string, "correct" | "incorrect">
  >({});
  const [profile, setProfile] = useState<LearnerProfile>(() => {
    const saved = readStoredJson<unknown>("nexiq-profile", null);
    if (
      saved &&
      typeof saved === "object" &&
      "name" in saved &&
      "goal" in saved &&
      typeof saved.name === "string" &&
      typeof saved.goal === "string"
    ) {
      return { name: saved.name, goal: saved.goal };
    }
    return { name: "Future Creator", goal: "" };
  });

  const xp = (completedLessons.length + completedChallenges.length) * 25;
  const aiCount = chatMessages.filter((message) => message.role === "user").length;
  const learnerLevel = Math.floor(xp / 500) + 1;
  const allLessons = initialCourses.flatMap((course) =>
    getLessonsForCourse(course.id),
  );
  const availableLessons = initialCourses
    .filter((course) => !course.vip)
    .flatMap((course) => getLessonsForCourse(course.id))
    .filter((lesson) => !lesson.isVip);
  const overallLessonCount = availableLessons.length;
  const overallCompletedCount = availableLessons.filter((lesson) =>
    completedLessons.includes(lesson.id),
  ).length;
  const overallProgress = overallLessonCount
    ? Math.round((overallCompletedCount / overallLessonCount) * 100)
    : 0;

  useEffect(() => {
    writeStoredJson("nexiq-language", language);
  }, [language]);
  useEffect(() => {
    writeStoredJson("nexiq-completed-challenges", completedChallenges);
  }, [completedChallenges]);
  useEffect(() => {
    writeStoredJson("nexiq-profile", profile);
  }, [profile]);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2800);
  };

  const getCourseProgress = (courseId: number) => {
    const courseLessons = getLessonsForCourse(courseId);
    if (courseLessons.length === 0) return 0;
    const completed = courseLessons.filter((lesson) =>
      completedLessons.includes(lesson.id),
    ).length;
    return Math.round((completed / courseLessons.length) * 100);
  };
  const coursesStarted = initialCourses.filter(
    (course) => getCourseProgress(course.id) > 0,
  );
  const continueCourse = initialCourses.find(
    (course) => getCourseProgress(course.id) > 0 && getCourseProgress(course.id) < 100,
  ) ?? initialCourses.find(
    (course) => !course.vip && getCourseProgress(course.id) < 100,
  );
  const latestCompletedLesson = [...completedLessons]
    .reverse()
    .map((id) => allLessons.find((lesson) => lesson.id === id))
    .find((lesson) => lesson !== undefined);

  const finishLesson = (lesson: { id: string }) => {
    if (completedLessons.includes(lesson.id)) {
      showNotice(language === "hy"
        ? "Այս դասն արդեն ավարտել ես։"
        : "You have already completed this lesson.");
      return;
    }

    const saved = completeLesson(lesson.id);
    setCompletedLessons((previous) =>
      previous.includes(lesson.id) ? previous : [...previous, lesson.id],
    );
    showNotice(saved
      ? language === "hy" ? "Դասն ավարտված է։ +25 XP" : "Lesson completed! +25 XP"
      : language === "hy"
        ? "Դասն ավարտվեց, բայց բրաուզերը չկարողացավ պահպանել առաջընթացը։"
        : "Lesson completed, but browser storage could not save your progress.");
  };

  const t = (key: TranslationKey): string => {
  return translations[language][key] ?? String(key);
  };

  const courses = initialCourses;

  const filteredCourses = useMemo(() => {
    const normalizedSearch = search.toLowerCase().trim();

    return courses.filter((course) => {
      const matchesCategory =
        category === "All" || course.category === category;

      const matchesSearch =
        !normalizedSearch ||
        course.title.toLowerCase().includes(normalizedSearch) ||
        course.description.toLowerCase().includes(normalizedSearch) ||
        course.category.toLowerCase().includes(normalizedSearch);

      return matchesCategory && matchesSearch;
    });
  }, [courses, category, search]);

  const navigate = (nextPage: Page) => {
    setPage(nextPage);
    setSelectedCourse(null);
    setMenuOpen(false);
  };

  const startCourse = (course: Course) => {
    if (course.vip) {
      showNotice(
        language === "hy"
          ? "Այս դասընթացի համար անհրաժեշտ է VIP անդամակցություն։"
          : "This course requires VIP membership.",
      );
      navigate("vip");
      return;
    }

    setSelectedCourse(course);
    const lessonsForCourse = getLessonsForCourse(course.id);
    const nextLessonIndex = lessonsForCourse.findIndex(
      (lesson) => !completedLessons.includes(lesson.id),
    );
    setActiveLessonIndex(nextLessonIndex >= 0 ? nextLessonIndex : 0);
  };

  const submitChallenge = (
    id: string,
    answerValue: string,
    expectedAnswer: string,
  ) => {
    if (completedChallenges.includes(id)) return;
    const isCorrect = answerValue.trim().toLowerCase() === expectedAnswer;
    setChallengeFeedback((previous) => ({
      ...previous,
      [id]: isCorrect ? "correct" : "incorrect",
    }));
    if (isCorrect) {
      setCompletedChallenges((previous) =>
        previous.includes(id) ? previous : [...previous, id],
      );
      showNotice(language === "hy"
        ? "Ճիշտ է։ +25 XP"
        : "Correct answer! +25 XP");
    }
  };

  const askAI = () => {
    const trimmedQuestion = question.trim();
    if (!trimmedQuestion) return;

    const reply = language === "hy"
      ? `Լավ հարց է։ «${trimmedQuestion}» թեման սովորելու համար նախ հստակեցրու հիմնական գաղափարը, հետո փորձիր փոքր օրինակ և բացատրիր արդյունքը քո բառերով։ Սա Nexiq-ի տեղային ցուցադրական պատասխանն է, ոչ թե միացված AI մոդելի պատասխան։`
      : `Good question. To learn about "${trimmedQuestion}", first identify the core idea, try a small example, then explain the result in your own words. This is a local demo reply, not a response from a connected AI model.`;
    setChatMessages((previous) => [
      ...previous,
      { id: Date.now(), role: "user", text: trimmedQuestion },
      { id: Date.now() + 1, role: "assistant", text: reply },
    ]);
    setQuestion("");
  };

  const renderCourseCard = (course: Course) => {
    const Icon = course.icon;

    return (
      <article className="course-card" key={course.id}>
        <div className={`course-art ${course.color}`}>
          <div className="course-art-top">
            <span className="course-category">
              {translatedCategory(course.category, language)}
            </span>
            <span className={course.vip ? "vip-badge" : "free-badge"}>
              {course.vip ? (
                <>
                  <Crown size={12} /> {t("premium")}
                </>
              ) : (
                t("free")
              )}
            </span>
          </div>

          <div className="course-art-icon">
            <Icon size={42} strokeWidth={1.6} />
          </div>

          <span className="art-index">
            NEXIQ / {String(course.id).padStart(2, "0")}
          </span>
        </div>

        <div className="course-content">
          <div className="course-meta">
            <span>
              <BookOpen size={14} /> {course.lessons} {t("lessons")}
            </span>
            <span>
              <Zap size={14} /> {course.xp} XP
            </span>
          </div>

          <h3>{translatedCourseTitle(course, language)}</h3>
          <p>{translatedCourseDescription(course, language)}</p>

          {getCourseProgress(course.id) > 0 && (
            <div className="course-progress">
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{
                    width: `${getCourseProgress(course.id)}%`,
                  }}
                />
              </div>
              <span>{getCourseProgress(course.id)}% complete</span>
            </div>
          )}

          <button
            className={`course-action ${course.vip ? "locked-action" : ""}`}
            onClick={() => startCourse(course)}
          >
            {course.vip ? (
              <>
                <LockKeyhole size={15} /> Explore VIP
              </>
            ) : (
              <>
                  {getCourseProgress(course.id) === 100
                    ? language === "hy" ? "Դիտել դասընթացը" : "Review course"
                    : t("continueLearning")} <ArrowUpRight size={16} />
              </>
            )}
          </button>
        </div>
      </article>
    );
  };

  const renderHeading = (
    eyebrow: string,
    title: string,
    description: string,
  ) => (
    <div className="page-heading">
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      <p>{description}</p>
    </div>
  );

  const renderDashboard = () => (
    <>

    <section className="hero">
      <div className="hero-content">
        <div className="hero-proof">
          <span className="live-dot" />
          {language === "hy"
            ? "ՔՈ ՆՈՐ ՄԱԿԱՐԴԱԿԸ ՍԿՍՎՈՒՄ Է ԱՅՍՏԵՂ"
            : "YOUR NEXT LEVEL STARTS HERE"}
        </div>

          <h1>
            Learn smarter.
            <br />
            <span>Become unstoppable.</span>
          </h1>
          <p>
            Build real-world skills, complete challenges, and turn your
            progress into achievements.
          </p>
          <div className="hero-actions">
            <button
              className="button-primary"
              onClick={() => navigate("courses")}
            >
              Explore courses <ArrowRight size={17} />
            </button>
            <button
              className="button-secondary"
              onClick={() => navigate("challenges")}
            >
              <Target size={17} /> {t("challenges")}
            </button>
          </div>
          <div className="hero-caption">
            <Sparkles size={15} />
            Learn. Earn. Evolve.
          </div>
        </div>

        <div className="hero-visual" aria-hidden="true">
          <div className="visual-ring ring-one" />
          <div className="visual-ring ring-two" />
          <div className="visual-core">
            <GraduationCap size={54} />
            <span>NEXIQ</span>
          </div>
          <div className="floating-card floating-xp">
            <Zap size={17} />
            <div>
              <strong>{xp} XP</strong>
              <small>Total earned</small>
            </div>
          </div>
          <div className="floating-card floating-level">
            <Trophy size={18} />
            <div>
              <strong>{language === "hy" ? "Մակարդակ" : "Level"} {learnerLevel}</strong>
              <small>Rising learner</small>
            </div>
          </div>
          <span className="visual-dot dot-one" />
          <span className="visual-dot dot-two" />
        </div>
      </section>

      <section className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon orange">
            <Zap size={20} />
          </div>
          <div>
            <span className="stat-label">{t("totalXP")}</span>
            <strong>{xp.toLocaleString()}</strong>
            <small>Keep moving forward</small>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">
            <BookOpen size={20} />
          </div>
          <div>
            <span className="stat-label">{t("myCourses")}</span>
            <strong>{coursesStarted.length}</strong>
            <small>Learning in progress</small>
          </div>
        </div>
        <div className="stat-card">
            <div className="stat-icon green">
              <BookOpen size={20} />
          </div>
          <div>
            <span className="stat-label">{language === "hy" ? "Ավարտված դասեր" : "Lessons completed"}</span>
          <strong>{overallCompletedCount}</strong>
            <small>{language === "hy" ? `Ընդամենը ${overallLessonCount} անվճար դասից` : `Out of ${overallLessonCount} available free lessons`}</small>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">
            <Trophy size={20} />
          </div>
          <div>
            <span className="stat-label">Challenges</span>
            <strong>{completedChallenges.length}/{challengeIds.length}</strong>
            <small>{language === "hy" ? "Լուծված առաջադրանքներ" : "Challenges completed"}</small>
          </div>
        </div>
      </section>

      <section className="level-card">
        <div className="level-heading">
          <div className="level-avatar"><BookOpen size={24} /></div>
          <div>
            <span className="eyebrow">{language === "hy" ? "ԸՆԴՀԱՆՈՒՐ ԱՌԱՋԸՆԹԱՑ" : "OVERALL LEARNING PROGRESS"}</span>
            <h3>{overallCompletedCount} / {overallLessonCount} {t("lessons")}</h3>
            <p>{language === "hy" ? "Անվճար հասանելի դասերի առաջընթացը" : "Progress across lessons available in the free demo"}</p>
          </div>
          <span className="level-xp">{overallProgress}%</span>
        </div>
        <div className="progress-track" role="progressbar" aria-label="Overall learning progress" aria-valuenow={overallProgress} aria-valuemin={0} aria-valuemax={100}>
          <div className="progress-fill" style={{ width: `${overallProgress}%` }} />
        </div>
      </section>

      <section className="level-card">
        <div className="level-heading">
          <div className="level-avatar">
            <GraduationCap size={24} />
          </div>
          <div>
            <span className="eyebrow">YOUR JOURNEY</span>
            <h3>{language === "hy" ? `Մակարդակ ${learnerLevel} — Զարգացող սովորող` : `Level ${learnerLevel} — Rising Learner`}</h3>
            <p>Every lesson takes you further.</p>
          </div>
          <span className="level-xp">{xp % 500} / 500 XP</span>
        </div>
        <div className="progress-track">
          <div
            className="progress-fill"
            style={{ width: `${(xp % 500) / 5}%` }}
          />
        </div>
        <div className="progress-labels">
          <span>{language === "hy" ? `Մակարդակ ${learnerLevel}` : `Level ${learnerLevel}`}</span>
          <span>{500 - (xp % 500)} XP to next level</span>
        </div>
      </section>

      <section className="page-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">{language === "hy" ? "ՇԱՐՈՒՆԱԿԻՐ ՔՈ ՈՒՂԻՆ" : "PICK UP WHERE YOU LEFT OFF"}</span>
            <h2>{language === "hy" ? "Շարունակել ուսուցումը" : "Continue learning"}</h2>
          </div>
          {continueCourse && (
            <button className="text-link" onClick={() => startCourse(continueCourse)}>
              {language === "hy" ? "Բացել դասընթացը" : "Open course"} <ArrowRight size={16} />
            </button>
          )}
        </div>
        {continueCourse ? (
          <div className="course-grid">{renderCourseCard(continueCourse)}</div>
        ) : (
          <div className="empty-state">
            <BookOpen size={28} />
            <h3>{language === "hy" ? "Դեռ ուսուցման ակտիվություն չկա" : "Your learning activity will appear here"}</h3>
            <p>{language === "hy" ? "Սկսիր անվճար դասընթացից․ առաջընթացը կպահպանվի այս բրաուզերում։" : "Start a free course. Your progress is saved in this browser."}</p>
            <button className="button-secondary" onClick={() => navigate("courses")}>{t("exploreCourses")}</button>
          </div>
        )}
        <div className="recent-activity">
          <strong>{language === "hy" ? "Վերջին գործունեություն" : "Recent activity"}</strong>
          <p>{latestCompletedLesson
            ? `${language === "hy" ? "Ավարտված դաս" : "Completed lesson"}: ${latestCompletedLesson.title[language]}`
            : language === "hy" ? "Ավարտված դասեր դեռ չկան։" : "No lessons completed yet."}</p>
        </div>
      </section>

      <section className="page-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">HANDPICKED FOR YOU</span>
            <h2>Featured courses</h2>
            <p>Skills worth investing your time in.</p>
          </div>
          <button className="text-link" onClick={() => navigate("courses")}>
            View all <ArrowRight size={16} />
          </button>
        </div>
        <div className="course-grid">
          {courses.slice(0, 3).map(renderCourseCard)}
        </div>
      </section>

      <section className="feature-grid">
        <article className="feature-card challenge-feature">
          <div className="feature-icon">
            <Target size={23} />
          </div>
          <span className="feature-eyebrow">DAILY QUEST</span>
          <h3>Small steps. Big progress.</h3>
          <p className="feature-description">
            Complete daily tasks and earn XP while building your skills.
          </p>
          <button className="feature-link" onClick={() => navigate("challenges")}>
            View challenges <ArrowRight size={16} />
          </button>
        </article>

        <article className="feature-card ai-feature">
          <div className="feature-icon">
            <Bot size={23} />
          </div>
          <span className="feature-eyebrow">YOUR AI COMPANION</span>
          <h3>Questions welcome.</h3>
          <p className="feature-description">
            Explore ideas, clarify concepts, and keep your curiosity alive.
          </p>
          <button className="feature-link" onClick={() => navigate("aiTutor")}>
            Meet AI Tutor <ArrowRight size={16} />
          </button>
        </article>
      </section>

      <section className="vip-banner">
        <div className="vip-banner-icon">
          <Crown size={27} />
        </div>
        <div className="vip-banner-copy">
          <span className="eyebrow">GO BEYOND THE BASICS</span>
          <h2>Unlock your full potential.</h2>
          <p>Discover exclusive courses and a more powerful learning journey.</p>
        </div>
        <button className="button-primary" onClick={() => navigate("vip")}>
          Discover VIP <ArrowRight size={16} />
        </button>
      </section>
    </>
  );

  const renderCourses = () => (
    <>
      {renderHeading(
        "YOUR LEARNING LIBRARY",
        "Explore courses",
        "Find your next skill and learn at your own pace.",
      )}

      <div className="course-toolbar">
        <label className="search-box">
          <Search size={18} />
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search courses..."
          />
          {search && (
            <button
              className="icon-button"
              aria-label="Clear search"
              onClick={() => setSearch("")}
            >
              <X size={16} />
            </button>
          )}
        </label>
        <span className="course-count">{filteredCourses.length} courses</span>
      </div>

      <div className="category-list">
        {categories.map((item) => (
          <button
            key={item}
            className={`category-chip ${category === item ? "active" : ""}`}
            onClick={() => setCategory(item)}
          >
            {translatedCategory(item, language)}
          </button>
        ))}
      </div>

      {filteredCourses.length ? (
        <div className="course-grid">
          {filteredCourses.map(renderCourseCard)}
        </div>
      ) : (
        <div className="empty-state">
          <Search size={30} />
          <h3>No courses found</h3>
          <p>Try a different search or category.</p>
          <button
            className="button-secondary"
            onClick={() => {
              setSearch("");
              setCategory("All");
            }}
          >
            Clear filters
          </button>
        </div>
      )}
    </>
  );


const renderCourseDetail = () => {
  if (!selectedCourse) return null;

  const Icon = selectedCourse.icon;

  const lessonContent: Record<number, string[]> =
    language === "hy"
      ? {
          1: [
            "Ծրագրավորման ներածություն",
            "Փոփոխականներ և տվյալների տեսակներ",
            "Պայմաններ և ցիկլեր",
            "Գործնական առաջադրանք",
          ],
          2: [
            "Ծանոթություն AI գործիքներին",
            "AI-ի արդյունավետ օգտագործում",
            "Աշխատանքի ավտոմատացում",
            "Ստեղծիր քո առաջին AI նախագիծը",
          ],
          3: [
            "UI/UX դիզայնի հիմունքներ",
            "Գույներ և տառատեսակներ",
            "Օգտատիրոջ փորձառություն",
            "Նախագծիր քո առաջին էջը",
          ],
          4: [
            "Թվային մարքեթինգի հիմունքներ",
            "Սոցիալական մեդիայի ռազմավարություն",
            "Բովանդակության ստեղծում",
            "Կազմիր մարքեթինգային պլան",
          ],
          5: [
            "Տեսանյութերի ստեղծման հիմունքներ",
            "Նկարահանում և կադրեր",
            "Մոնտաժի հիմունքներ",
            "Ստեղծիր քո առաջին տեսանյութը",
          ],
          6: [
            "Վեբ ծրագրավորման հիմունքներ",
            "Ժամանակակից վեբ գործիքներ",
            "Կայքի կառուցվածք և ոճավորում",
            "Ստեղծիր քո սեփական կայքը",
          ],
        }
      : {
          1: [
            "Introduction to Programming",
            "Variables and Data Types",
            "Conditions and Loops",
            "Practical Challenge",
          ],
          2: [
            "Introduction to AI Tools",
            "Using AI Effectively",
            "Workflow Automation",
            "Build Your First AI Project",
          ],
          3: [
            "UI/UX Design Fundamentals",
            "Colors and Typography",
            "User Experience",
            "Design Your First Screen",
          ],
          4: [
            "Digital Marketing Basics",
            "Social Media Strategy",
            "Content Creation",
            "Build a Marketing Plan",
          ],
          5: [
            "Video Production Basics",
            "Filming and Composition",
            "Video Editing Fundamentals",
            "Create Your First Video",
          ],
          6: [
            "Web Development Fundamentals",
            "Modern Web Tools",
            "Website Structure and Styling",
            "Build Your Own Website",
          ],
        };

  const legacyLessonTitles = lessonContent[selectedCourse.id] ?? [];
  const courseLessons = getLessonsForCourse(selectedCourse.id);
  const completedForCourse = courseLessons
    .filter((lesson) => completedLessons.includes(lesson.id))
    .map((lesson) => lesson.id);
  const completedCount = completedForCourse.length;
  const progressPercent = courseLessons.length
    ? Math.round((completedCount / courseLessons.length) * 100)
    : 0;


  const lessonExplanations: Record<number, string[]> =
  language === "hy"
    ? {
        1: [
          "Ծրագրավորումը համակարգչին հրահանգներ տալու գործընթացն է։ Օրինակ՝ կարող ես ստեղծել ծրագիր, որը հաշվում է երկու թվերի գումարը։",
          "Փոփոխականը տվյալ պահելու տեղ է։ JavaScript-ում՝ const name = 'Անի';։ Տվյալների տեսակների օրինակներ են տեքստը, թիվը և true/false արժեքները։",
          "if պայմանը թույլ է տալիս որոշում կայացնել, իսկ ցիկլը՝ կրկնել գործողությունները։ Օրինակ՝ if (age >= 18) ստուգում է տարիքը։",
          "Փորձիր գրել մի փոքր ծրագիր, որը պահում է քո անունը և տպում ողջույնի հաղորդագրություն։",
        ],
        2: [
          "Արհեստական բանականության գործիքները կարող են օգնել սովորել, գրել, վերլուծել և ստեղծագործել։",
          "Հստակ նշիր խնդիրը, տրամադրիր անհրաժեշտ համատեքստ և խնդրիր կոնկրետ արդյունք։ Ստուգիր ստացված պատասխանը։",
          "Ավտոմատացումը կրկնվող աշխատանքը կատարում է նախապես սահմանված քայլերով։ Նախ որոշիր՝ որ աշխատանքն է պետք պարզեցնել։",
          "Մտածիր մի փոքր նախագծի մասին, որտեղ AI-ն օգնում է լուծել կոնկրետ խնդիր։ Գրիր նպատակը և քայլերը։",
        ],
        3: [
          "UI-ն էջի տեսանելի մասն է, իսկ UX-ը՝ այն օգտագործելու ամբողջ փորձառությունը։",
          "Ընտրիր իրար համապատասխանող գույներ և հեշտ ընթերցվող տառատեսակներ։ Պահպանիր վերնագրերի ու տեքստերի հստակ տարբերությունը։",
          "Լավ օգտատիրոջ փորձառությունը նշանակում է, որ մարդը հեշտությամբ գտնում է անհրաժեշտ տեղեկությունը և կատարում իր նպատակը։",
          "Նախագծիր մեկ էջ՝ վերնագրով, նկարագրությամբ և հստակ գործողության կոճակով։",
        ],
        4: [
          "Թվային մարքեթինգը համացանցի միջոցով մարդկանց տեղեկացնելու և նրանց հետ կապ ստեղծելու միջոց է։",
          "Ընտրիր հարթակը՝ ըստ լսարանի և նպատակի։ Յուրաքանչյուր հրապարակման համար նախապես որոշիր նպատակը։",
          "Օգտակար բովանդակությունը պետք է համապատասխանի լսարանի հետաքրքրություններին և ներկայացվի հասկանալի ձևով։",
          "Կազմիր մեկշաբաթյա պլան՝ նշելով հրապարակման թեման, հարթակը և նպատակը։",
        ],
        5: [
          "Տեսանյութի ստեղծումը սկսվում է գաղափարից, նպատակից և կարճ պլանից։",
          "Մտածիր լուսավորության, կադրի և ձայնի մասին։ Հստակ կադրը օգնում է դիտողին հասկանալ ասելիքը։",
          "Մոնտաժի ընթացքում ընտրիր անհրաժեշտ հատվածները, կարգավորիր հերթականությունը և ավելացրու ընթեռնելի վերնագրեր։",
          "Ստեղծիր կարճ տեսանյութի պլան՝ ներածությամբ, հիմնական մասով և ավարտով։",
        ],
        6: [
          "Վեբ կայքերը հաճախ կառուցվում են HTML-ով, ձևավորվում CSS-ով և դառնում ինտերակտիվ JavaScript-ով։",
          "Ժամանակակից գործիքները օգնում են գրել, փորձարկել և կազմակերպել կոդը։ Ընտրիր գործիքներ՝ ըստ նախագծի կարիքների։",
          "HTML-ը սահմանում է էջի կառուցվածքը, իսկ CSS-ը՝ գույները, չափերը և դասավորությունը։",
          "Ստեղծիր փոքր էջ՝ վերնագրով, նկարագրությամբ և կոճակով։ Այնուհետև ձևավորիր այն CSS-ով։",
        ],
      }
    : {
        1: [
          "Programming is the process of giving instructions to a computer. For example, you can create a program that adds two numbers.",
          "A variable stores data. In JavaScript: const name = 'Ani'; Common data types include text, numbers, and true/false values.",
          "An if statement makes a decision, while a loop repeats an action. For example, if (age >= 18) checks an age.",
          "Try writing a small program that stores your name and prints a greeting.",
        ],
        2: [
          "AI tools can help with learning, writing, analysis, and creative work.",
          "Describe the task clearly, provide context, and ask for a specific result. Always review the answer.",
          "Automation uses predefined steps to handle repetitive work. First identify the task you want to simplify.",
          "Think of a small project where AI could help solve a specific problem. Write down its goal and steps.",
        ],
        3: [
          "UI is the visible interface, while UX is the overall experience of using it.",
          "Choose colors that work well together and readable fonts. Keep headings and body text visually distinct.",
          "Good user experience helps people find information and complete their goals easily.",
          "Design one screen with a heading, description, and clear action button.",
        ],
        4: [
          "Digital marketing uses online channels to inform people and build connections with an audience.",
          "Choose a platform based on your audience and goal. Decide the purpose of each post in advance.",
          "Useful content matches the audience's interests and communicates ideas clearly.",
          "Create a one-week plan with a topic, platform, and goal for each post.",
        ],
        5: [
          "Video production starts with an idea, a goal, and a short plan.",
          "Consider lighting, framing, and sound. A clear shot helps viewers understand your message.",
          "Editing involves selecting clips, arranging them, and adding readable titles when useful.",
          "Plan a short video with an introduction, main section, and ending.",
        ],
        6: [
          "Websites often use HTML for structure, CSS for styling, and JavaScript for interactivity.",
          "Modern tools help you write, test, and organize code. Choose tools that fit your project's needs.",
          "HTML defines page structure, while CSS controls colors, sizes, and layout.",
          "Build a small page with a heading, description, and button, then style it with CSS.",
        ],
      };



  const labels =
    language === "hy"
      ? {
          back: "Վերադառնալ դասընթացներին",
          banner: "ՍՈՎՈՐԻՐ ՆՈՐ ԲԱՆ",
          lessons: "դաս",
          reward: "XP պարգև",
          content: "ԴԱՍԸՆԹԱՑԻ ԲՈՎԱՆԴԱԿՈՒԹՅՈՒՆ",
          path: "Քո ուսումնական ուղին",
          intro: "ՍԿԻԶԲ",
          free: "Անվճար դաս",
          locked: "VIP դաս",
          start: "Սկսել սովորել",
          demo: "Դասի մեկնարկը դեռ ցուցադրական է։",
        }
      : {
          back: "Back to courses",
          banner: "LEARN SOMETHING NEW",
          lessons: "lessons",
          reward: "XP reward",
          content: "COURSE CONTENT",
          path: "Your learning path",
          intro: "INTRO",
          free: "Free lesson",
          locked: "VIP lesson",
          start: "Start learning",
          demo: "Lesson playback is coming soon.",
        };

  return (
    <section className="course-detail">
      <button
        className="back-button"
        onClick={() => setSelectedCourse(null)}
      >
        <ArrowLeft size={17} /> {labels.back}
      </button>

      <div className={`course-detail-art ${selectedCourse.color}`}>
        <Icon size={64} strokeWidth={1.4} />
        <span>{labels.banner}</span>
      </div>

      <span className="eyebrow">
        {translatedCategory(selectedCourse.category, language)}
      </span>

      <h1>{translatedCourseTitle(selectedCourse, language)}</h1>

      <p className="detail-description">
        {translatedCourseDescription(selectedCourse, language)}
      </p>

      <div className="detail-info">
        <span>
          <BookOpen size={17} />
          {selectedCourse.lessons} {labels.lessons}
        </span>

        <span>
          <Zap size={17} />
          {selectedCourse.xp} {labels.reward}
        </span>

        <span>
          <Play size={17} />
          {selectedCourse.duration}
        </span>
      </div>

      <div className="lesson-preview">
        <div className="lesson-preview-heading">
          <div>
            <span className="eyebrow">{labels.content}</span>
            <h3>{labels.path}</h3>
          </div>

          <span className="free-badge">{labels.intro}</span>
        </div>

        <div className="course-progress">
          <div className="progress-track">
            <div className="progress-fill" style={{ width: `${progressPercent}%` }} />
          </div>
          <span>{progressPercent}% {language === "hy" ? "ավարտված" : "complete"} · {completedCount}/{courseLessons.length}</span>
        </div>

        <div
          className="lesson-content"
          key={`${selectedCourse.id}-${activeLessonIndex}`}
        >
          <h2>{courseLessons[activeLessonIndex]?.title[language] ?? legacyLessonTitles[activeLessonIndex]}</h2>

          <p
            className="lesson-explanation"
            style={{
              display: "block",
              visibility: "visible",
              opacity: 1,
              color: "inherit",
              fontSize: "16px",
              lineHeight: 1.8,
              whiteSpace: "normal",
            }}
          >
            {courseLessons[activeLessonIndex]?.content[language] ??
              lessonExplanations[selectedCourse.id]?.[activeLessonIndex] ??
              "Այս դասի բացատրությունը դեռ ավելացված չէ։"}
          </p>
        </div>


        {courseLessons.map((lesson, index) => {
          const isLocked = selectedCourse.vip || lesson.isVip;
          const isCompleted = completedForCourse.includes(lesson.id);

          return (
 
          <button
            type="button"
            className="lesson-row"
            key={lesson.id}
            onClick={() => {
              if (isLocked) {
                showNotice(
                  language === "hy"
                    ? "Այս դասը հասանելի է միայն VIP օգտատերերին։"
                    : "This lesson is available to VIP users only."
                );
                return;
              }

              setActiveLessonIndex(index);
            }}
          >

              <span className="lesson-number">
                {String(index + 1).padStart(2, "0")}
              </span>

              <span>{lesson.title[language]}</span>

              {isLocked ? (
                <LockKeyhole size={15} aria-label={labels.locked} />
              ) : isCompleted ? (
                <Check size={17} color="#22c55e" aria-label="Completed" />
              ) : (
                <Play size={16} aria-label={labels.free} />
              )}
            </button>
          );
        })}

      <button
        className="button-primary full-button"
        disabled={
          !courseLessons[activeLessonIndex] ||
          selectedCourse.vip ||
          Boolean(courseLessons[activeLessonIndex]?.isVip) ||
          completedForCourse.includes(courseLessons[activeLessonIndex]?.id ?? "")
        }
        onClick={() => {
          const activeLesson = courseLessons[activeLessonIndex];
          if (!activeLesson) return;
          if (selectedCourse.vip || activeLesson.isVip) {
            showNotice(
              language === "hy"
                ? "Այս դասի համար անհրաժեշտ է VIP։"
                : "VIP is required for this lesson.",
            );
            return;
          }

          finishLesson(activeLesson);
        }}
      >
        <Check size={17} />
        {completedForCourse.includes(courseLessons[activeLessonIndex]?.id ?? "")
          ? language === "hy"
            ? "Դասն ավարտված է"
            : "Lesson completed"
          : language === "hy"
            ? "Ավարտել դասը"
            : "Complete lesson"}
      </button>

      </div>
    </section>
  );
};


  const renderChallenges = () => {
    const challenges = [
      {
        id: "html-link",
        title: "HTML link element",
        description: "Which HTML element creates a hyperlink? Enter the element name without angle brackets.",
        reward: 25,
        icon: BookOpen,
        expectedAnswer: "a",
      },
      {
        id: "js-const",
        title: "JavaScript constants",
        description: "Which JavaScript keyword declares a block-scoped constant?",
        reward: 25,
        icon: MessageCircle,
        expectedAnswer: "const",
      },
      {
        id: "ux-goal",
        title: "UX fundamentals",
        description: "UX is short for user experience or user interface? Enter the missing word.",
        reward: 25,
        icon: Sparkles,
        expectedAnswer: "experience",
      },
    ];

    return (
      <>
        {renderHeading(
          "PRACTICE CHALLENGES",
          "Challenge yourself",
          "Answer beginner-friendly questions to check your understanding and earn XP.",
        )}

        <div className="challenge-panel">
          <div className="challenge-panel-top">
            <div className="large-feature-icon"><Target size={31} /></div>
            <div>
              <span className="eyebrow">PRACTICE SET</span>
              <h2>Learn, test, and earn XP.</h2>
              <p>Correct answers earn XP. You can retry any question.</p>
            </div>
          </div>

          <div className="challenge-progress-heading">
            <span>Challenge progress</span>
            <strong>{completedChallenges.length} / {challenges.length}</strong>
          </div>
          <div className="progress-track">
            <div
              className="progress-fill"
              style={{
                width: `${(completedChallenges.length / challenges.length) * 100}%`,
              }}
            />
          </div>

          <div className="challenge-list">
            {challenges.map((challenge) => {
              const Icon = challenge.icon;
              const completed = completedChallenges.includes(challenge.id);
              const feedback = challengeFeedback[challenge.id];

              return (
                <article
                  className={`challenge-item ${completed ? "completed" : ""}`}
                  key={challenge.id}
                >
                  <div className="challenge-item-icon"><Icon size={21} /></div>
                  <div className="challenge-item-copy">
                    <h3>{challenge.title}</h3>
                    <p>{challenge.description}</p>
                    <span className="challenge-reward">
                      <Zap size={13} /> +{challenge.reward} XP
                    </span>
                    <form
                      className="challenge-answer-form"
                      onSubmit={(event) => {
                        event.preventDefault();
                        submitChallenge(
                          challenge.id,
                          challengeAnswers[challenge.id] ?? "",
                          challenge.expectedAnswer,
                        );
                      }}
                    >
                      <label className="challenge-answer-label">
                        {language === "hy" ? "Քո պատասխանը" : "Your answer"}
                        <input
                          className={`challenge-answer-input ${feedback ?? ""}`}
                          value={challengeAnswers[challenge.id] ?? ""}
                          onChange={(event) => {
                            setChallengeAnswers((previous) => ({
                              ...previous,
                              [challenge.id]: event.target.value,
                            }));
                            setChallengeFeedback((previous) => {
                              const next = { ...previous };
                              delete next[challenge.id];
                              return next;
                            });
                          }}
                          aria-label={`${challenge.title} answer`}
                          disabled={completed}
                          required
                        />
                      </label>
                      {feedback === "incorrect" && !completed && (
                        <p className="challenge-feedback incorrect" role="status">
                          {language === "hy"
                            ? "Դեռ ճիշտ չէ։ Փորձիր նորից։"
                            : "Not quite. Review the question and try again."}
                        </p>
                      )}
                      {completed && (
                        <p className="challenge-feedback correct" role="status">
                          {language === "hy" ? "Ճիշտ պատասխան։" : "Correct answer."}
                        </p>
                      )}
                      <div className="challenge-actions">
                        <button
                          className={`challenge-complete ${completed ? "done" : ""}`}
                          type="submit"
                          disabled={completed || !(challengeAnswers[challenge.id] ?? "").trim()}
                        >
                          {completed
                            ? <><Check size={17} /> {language === "hy" ? "Ավարտված է" : "Completed"}</>
                            : language === "hy" ? "Ստուգել" : "Check answer"}
                        </button>
                        {feedback === "incorrect" && !completed && (
                          <button
                            className="challenge-retry"
                            type="button"
                            onClick={() => {
                              setChallengeAnswers((previous) => ({
                                ...previous,
                                [challenge.id]: "",
                              }));
                              setChallengeFeedback((previous) => {
                                const next = { ...previous };
                                delete next[challenge.id];
                                return next;
                              });
                            }}
                          >
                            {language === "hy" ? "Կրկին փորձել" : "Retry"}
                          </button>
                        )}
                      </div>
                    </form>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </>
    );
  };

  const renderAITutor = () => (
    <>
      {renderHeading(
        "YOUR PERSONAL LEARNING COMPANION",
        "AI Tutor",
        "Ask questions, explore ideas, and make difficult topics easier.",
      )}

      <section className="ai-panel">
        <div className="ai-panel-heading">
          <div className="ai-avatar"><Bot size={25} /></div>
          <div>
            <h2>Nexiq AI</h2>
            <p><span className="live-dot" /> Learning assistant demo</p>
          </div>
          <span className="ai-status">DEMO</span>
        </div>

        <div className="ai-conversation">
          {chatMessages.length === 0 && <div className="ai-message">
            <div className="ai-message-avatar"><Sparkles size={16} /></div>
            <div className="ai-message-body">
              <strong>Hey, learner!</strong>
              <p>
                I'm here to help you understand new concepts. Ask me about
                programming, design, AI, or anything you're learning.
              </p>
            </div>
          </div>}

          {chatMessages.map((message) => (
            <div className={`ai-message ${message.role === "user" ? "user-message" : ""}`} key={message.id}>
              <div className="ai-message-avatar">
                {message.role === "user" ? <UserRound size={16} /> : <Bot size={16} />}
              </div>
              <div className="ai-message-body">
                <strong>{message.role === "user" ? (language === "hy" ? "Դու" : "You") : "Nexiq AI"}</strong>
                <p>{message.text}</p>
              </div>
            </div>
          ))}
        </div>

        <form
          className="ai-input-row"
          onSubmit={(event) => {
            event.preventDefault();
            askAI();
          }}
        >
          <input
            value={question}
            onChange={(event) => setQuestion(event.target.value)}
            placeholder="Ask your learning question..."
            aria-label="Ask AI Tutor"
          />
          <button
            className="send-button"
            type="submit"
            disabled={!question.trim()}
            aria-label="Send question"
          >
            <Send size={18} />
          </button>
        </form>
        <p className="ai-disclaimer">
          <Sparkles size={13} /> Demo mode: responses are generated locally.
          A real AI API can be connected later.
        </p>

        <div className="ai-usage">
          <span>Questions asked in this session</span>
          <strong>{aiCount}</strong>
        </div>
      </section>

      <div className="feature-grid">
        {[
          ["Explain a concept", "Break down a difficult idea into simple steps."],
          ["Practice a skill", "Try examples and strengthen your understanding."],
        ].map(([title, description]) => (
          <article className="feature-card" key={title}>
            <div className="feature-icon"><Sparkles size={21} /></div>
            <h3>{title}</h3>
            <p className="feature-description">{description}</p>
          </article>
        ))}
      </div>
    </>
  );

  const renderAchievements = () => {
    const hasCompletedFreeCourse = courses.some(
      (course) => !course.vip && getCourseProgress(course.id) === 100,
    );
    const achievements = [
      {
        title: "First Steps",
        description: "Complete your first lesson.",
        icon: GraduationCap,
        unlocked: completedLessons.length >= 1,
      },
      {
        title: "Course Finisher",
        description: "Complete every lesson in a free course.",
        icon: BookOpen,
        unlocked: hasCompletedFreeCourse,
      },
      {
        title: "Quest Starter",
        description: "Complete your first challenge.",
        icon: Target,
        unlocked: completedChallenges.length > 0,
      },
      {
        title: "Five Lessons",
        description: "Complete five lessons.",
        icon: Flame,
        unlocked: completedLessons.length >= 5,
      },
      {
        title: "Challenge Set",
        description: "Complete all three practice challenges.",
        icon: Sparkles,
        unlocked: completedChallenges.length === challengeIds.length,
      },
      {
        title: "XP Collector",
        description: "Earn 500 XP from lessons and challenges.",
        icon: Zap,
        unlocked: xp >= 500,
      },
    ];

    return (
      <>
        {renderHeading(
          "YOUR MILESTONES",
          "Achievements",
          "Every small win is a step toward something bigger.",
        )}

        <div className="achievement-summary">
          <div className="achievement-summary-icon"><Trophy size={25} /></div>
          <div>
            <span className="eyebrow">COLLECTION PROGRESS</span>
            <h2>{achievements.filter((item) => item.unlocked).length} of {achievements.length} unlocked</h2>
          </div>
        </div>

        <div className="achievement-grid">
          {achievements.map((achievement) => {
            const Icon = achievement.icon;

            return (
              <article
                className={`achievement-card ${achievement.unlocked ? "unlocked" : "locked"}`}
                key={achievement.title}
              >
                <div className="achievement-icon"><Icon size={27} /></div>
                {achievement.unlocked && (
                  <span className="achievement-unlocked"><Check size={13} /> UNLOCKED</span>
                )}
                <h3>{achievement.title}</h3>
                <p>{achievement.description}</p>
                {!achievement.unlocked && <LockKeyhole size={15} className="achievement-lock" />}
              </article>
            );
          })}
        </div>
      </>
    );
  };

  const renderVIP = () => (
    <>
      {renderHeading(
        "THE NEXT LEVEL",
        "Meet Nexiq VIP",
        "Explore the possibilities of a more advanced learning experience.",
      )}

      <section className="vip-page-hero">
        <div className="vip-page-icon"><Crown size={35} /></div>
        <span className="vip-label">NEXIQ / PREMIUM</span>
        <h2>More skills. More possibilities.</h2>
        <p>
          Explore exclusive learning paths and unlock new ways to grow.
          Membership and payments are not enabled in this demo.
        </p>
        <div className="vip-price">
          <strong>VIP</strong>
          <span>Premium learning experience</span>
        </div>
      </section>

      <div className="vip-benefits">
        {[
          ["Exclusive courses", "Explore advanced learning paths."],
          ["Deeper learning", "Build on your skills with focused lessons."],
          ["More challenges", "Discover additional ways to practice."],
          ["Learning milestones", "Keep track of your progress."],
        ].map(([title, description], index) => (
          <div className="benefit-row" key={title}>
            <div className="benefit-check"><Check size={17} /></div>
            <div className="benefit-copy">
              <h3>{title}</h3>
              <p>{description}</p>
            </div>
            <span className="benefit-number">0{index + 1}</span>
          </div>
        ))}
      </div>

      <div className="vip-note">
        <LockKeyhole size={17} />
        <p>
          This is a preview only. Real VIP access, subscriptions, and payments
          must be connected securely on the backend.
        </p>
      </div>
    </>
  );

  const renderProfile = () => (
    <>
      {renderHeading(
        "YOUR PERSONAL SPACE",
        "My Profile",
        "Your learning identity and progress, all in one place.",
      )}

      <section className="profile-card">
        <div className="profile-cover">
          <div className="profile-cover-orb" />
        </div>
        <div className="profile-details">
          <div className="profile-avatar"><UserRound size={33} /></div>
          <div className="profile-name-row">
            <div>
              <h2>{profile.name.trim() || (language === "hy" ? "Սովորող" : "Learner")}</h2>
              <p>{language === "hy" ? "Տեղային պրոֆիլ՝ այս բրաուզերում" : "Local profile in this browser"}</p>
            </div>
            <span className="profile-level">{language === "hy" ? "ՄԱԿԱՐԴԱԿ" : "LEVEL"} {learnerLevel}</span>
          </div>
          <div className="profile-edit-form">
            <label>
              {language === "hy" ? "Անուն" : "Display name"}
              <input
                value={profile.name}
                maxLength={40}
                onChange={(event) => setProfile((previous) => ({
                  ...previous,
                  name: event.target.value,
                }))}
              />
            </label>
            <label>
              {language === "hy" ? "Ուսումնական նպատակ" : "Learning goal"}
              <input
                value={profile.goal}
                maxLength={100}
                placeholder={language === "hy" ? "Օրինակ՝ սովորել JavaScript" : "e.g. Learn JavaScript"}
                onChange={(event) => setProfile((previous) => ({
                  ...previous,
                  goal: event.target.value,
                }))}
              />
            </label>
            <small>{language === "hy"
              ? "Այս տվյալները պահպանվում են միայն ընթացիկ բրաուզերում։"
              : "These fields are saved only in this browser."}</small>
          </div>
          <div className="profile-stats">
            <div><strong>{xp}</strong><span>Total XP</span></div>
            <div><strong>{completedChallenges.length}</strong><span>Challenges</span></div>
            <div><strong>{coursesStarted.length}</strong><span>Courses started</span></div>
          </div>
        </div>
      </section>

      <section className="page-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">YOUR LEARNING</span>
            <h2>Continue your journey</h2>
          </div>
        </div>
        {coursesStarted.length > 0
          ? <div className="course-grid">{coursesStarted.map(renderCourseCard)}</div>
          : <p className="profile-empty">{language === "hy" ? "Սկսիր դասընթաց՝ քո առաջընթացն այստեղ տեսնելու համար։" : "Start a course to see your learning progress here."}</p>}
      </section>

      <button className="settings-shortcut" onClick={() => navigate("settings")}>
        <Settings size={18} />
        <span><strong>Account preferences</strong><small>Manage your app settings</small></span>
        <ChevronRight size={18} />
      </button>
    </>
  );

  const renderSettings = () => (
    <>
      {renderHeading(
        "MAKE IT YOURS",
        "Settings",
        "Choose how Nexiq works for you.",
      )}

      <section className="settings-card">
        <div className="settings-row">
          <div className="settings-icon"><Globe size={20} /></div>
          <div className="settings-copy">
            <h3>App language</h3>
            <p>Choose your preferred language.</p>
          </div>
          <select
            className="language-select"
            value={language}
            onChange={(event) => setLanguage(event.target.value as Language)}
            aria-label="App language"
          >
            <option value="en">English</option>
            <option value="hy">Հայերեն</option>
          </select>
        </div>

        <div className="settings-row">
          <div className="settings-icon"><Sparkles size={20} /></div>
          <div className="settings-copy">
            <h3>Learning experience</h3>
            <p>Personalized recommendations are in demo mode.</p>
          </div>
          <span className="settings-tag">DEMO</span>
        </div>

        <div className="settings-row">
          <div className="settings-icon"><LockKeyhole size={20} /></div>
          <div className="settings-copy">
            <h3>Privacy and security</h3>
            <p>Authentication and account controls will be added later.</p>
          </div>
          <ChevronRight size={18} />
        </div>

        <div className="settings-row">
          <div className="settings-icon"><Bot size={20} /></div>
          <div className="settings-copy">
            <h3>AI Tutor</h3>
            <p>AI responses are currently simulated.</p>
          </div>
          <button className="text-link" onClick={() => navigate("aiTutor")}>
            Open <ArrowUpRight size={15} />
          </button>
        </div>
      </section>

      <div className="settings-footer">
        <span>NEXIQ</span>
        <span>Learn. Earn. Evolve.</span>
        <span>Frontend demo · v1.0</span>
      </div>
    </>
  );

  const renderCurrentPage = () => {
    if (selectedCourse) return renderCourseDetail();

    switch (page) {
      case "dashboard":
        return renderDashboard();
      case "courses":
        return renderCourses();
      case "challenges":
        return renderChallenges();
      case "aiTutor":
        return renderAITutor();
      case "achievements":
        return renderAchievements();
      case "vip":
        return renderVIP();
      case "profile":
        return renderProfile();
      case "settings":
        return renderSettings();
      default:
        return renderDashboard();
    }
  };

  const navigationItems: Page[] = [
    "dashboard",
    "courses",
    "challenges",
    "aiTutor",
    "achievements",
  ];

  return (
  <LocalizedUI language={language}>
    <div className="app-shell">
      {menuOpen && (
        <button
          className="menu-backdrop"
          aria-label="Close menu"
          onClick={() => setMenuOpen(false)}
        />
      )}

      <header className="topbar">
        <button
          className="brand"
          onClick={() => navigate("dashboard")}
          aria-label="Nexiq home"
        >
          <span className="brand-mark"><Zap size={23} fill="currentColor" /></span>
          <span className="brand-copy">
            <strong>NEXIQ<span>.</span></strong>
            <small>LEARN. EARN. EVOLVE.</small>
          </span>
        </button>

        <nav className="desktop-nav" aria-label="Main navigation">
          {navigationItems.slice(0, 4).map((item) => {
            const Icon = pageIcons[item];

            return (
              <button
                className={`nav-link ${page === item && !selectedCourse ? "active" : ""}`}
                key={item}
                onClick={() => navigate(item)}
              >
                <Icon size={16} />
                {pageLabels[item]}
              </button>
            );
          })}
        </nav>

        <div className="topbar-actions">
          <select
            className="language-select top-language"
            value={language}
            onChange={(event) => setLanguage(event.target.value as Language)}
            aria-label="Select language"
          >
            <option value="en">EN</option>
            <option value="hy">ՀՅ</option>
          </select>

          <button
            className={`top-vip-button ${page === "vip" ? "active" : ""}`}
            onClick={() => navigate("vip")}
          >
            <Crown size={15} /> VIP
          </button>

          <button
            className="avatar-button"
            onClick={() => navigate("profile")}
            aria-label="Open profile"
          >
            <UserRound size={18} />
          </button>

          <button
            className="menu-button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <aside className={`side-menu ${menuOpen ? "visible" : ""}`}>
        <div className="side-menu-heading">WORKSPACE</div>

        <nav className="menu-items" aria-label="Workspace">
          {navigationItems.map((item) => {
            const Icon = pageIcons[item];

            return (
              <button
                className={`menu-item ${page === item && !selectedCourse ? "active" : ""}`}
                key={item}
                onClick={() => navigate(item)}
              >
                <Icon size={18} />
                <span>{pageLabels[item]}</span>
                {item === "challenges" && (
                  <span className="menu-count">
                    {Math.max(challengeIds.length - completedChallenges.length, 0)}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="side-menu-divider" />
        <div className="side-menu-heading">YOUR ACCOUNT</div>

        {(["profile", "settings"] as Page[]).map((item) => {
          const Icon = pageIcons[item];

          return (
            <button
              className={`menu-item ${page === item ? "active" : ""}`}
              key={item}
              onClick={() => navigate(item)}
            >
              <Icon size={18} />
              <span>{pageLabels[item]}</span>
            </button>
          );
        })}

        <button className="menu-vip" onClick={() => navigate("vip")}>
          <div className="menu-vip-icon"><Crown size={19} /></div>
          <div>
            <strong>Unlock Nexiq VIP</strong>
            <span>Take your skills further</span>
          </div>
          <ArrowUpRight size={17} />
        </button>

        <div className="menu-language">
          <span>{t("language").toUpperCase()}</span>
          <div className="language-toggle">
            <button
              className={language === "en" ? "selected" : ""}
              onClick={() => setLanguage("en")}
            >
              English
            </button>
            <button
              className={language === "hy" ? "selected" : ""}
              onClick={() => setLanguage("hy")}
            >
              Հայերեն
            </button>
          </div>
        </div>

        <div className="side-menu-bottom">
          <span className="brand-mark small"><Zap size={16} fill="currentColor" /></span>
          <div>
            <strong>NEXIQ</strong>
            <small>Learn. Earn. Evolve.</small>
          </div>
          <span className="version-tag">v1.0</span>
        </div>
      </aside>

      <main className="main-content">
        <div className="mobile-welcome">
          <span>{language === "hy" ? "ԲԱՐԻ ՎԵՐԱԴԱՐՁ" : "WELCOME BACK"}</span>
          <strong>
            {language === "hy" ? "Պատրա՞ստ ես զարգանալ" : "Ready to evolve?"}
          </strong>
        </div>

        {renderCurrentPage()}

        <footer className="footer">
          <div className="footer-brand">
            <span className="brand-mark small"><Zap size={15} fill="currentColor" /></span>
            <strong>NEXIQ</strong>
          </div>
          <span>Learn. Earn. Evolve.</span>
          <span>Keep growing, one step at a time.</span>
        </footer>
      </main>

      <nav className="mobile-bottom-nav" aria-label="Mobile navigation">
        {(
          ["dashboard", "courses", "challenges", "aiTutor", "profile"] as Page[]
        ).map((item) => {
          const Icon = pageIcons[item];

          return (
            <button
              key={item}
              className={`bottom-nav-item ${page === item && !selectedCourse ? "active" : ""}`}
              onClick={() => navigate(item)}
            >
              <Icon size={20} />
              <span>
                {item === "dashboard"
                  ? "Home"
                  : item === "aiTutor"
                    ? "AI Tutor"
                    : item === "challenges"
                      ? "Quests"
                      : item === "profile"
                        ? "Profile"
                        : "Courses"}
              </span>
            </button>
          );
        })}
      </nav>

      {notice && (
        <div className="toast" role="status">
          <Check size={18} />
          <span>{notice}</span>
          <button onClick={() => setNotice("")} aria-label="Dismiss notice">
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  </LocalizedUI>
  );
}

function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/lesson/:lessonId" element={<LessonPage />} />
        <Route path="/*" element={<App />} />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRouter;