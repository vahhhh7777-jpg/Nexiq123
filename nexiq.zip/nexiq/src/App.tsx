import { BrowserRouter, Routes, Route } from "react-router-dom";
import LessonPage from "./pages/LessonPage";
import { useNavigate } from "react-router-dom";
import {
  completeLesson,
  getCompletedLessons,
} from "./data/progress";
import {
  Children,
  cloneElement,
  Fragment,
  isValidElement,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Bot,
  Check,
  ChevronRight,
  Code2,
  Crown,
  Flame,
  Globe,
  GraduationCap,
  LayoutDashboard,
  LockKeyhole,
  Menu,
  MessageCircle,
  Palette,
  Play,
  Search,
  Send,
  Settings,
  Sparkles,
  Target,
  Trophy,
  UserRound,
  Video,
  X,
  Zap,
  Megaphone,
} from "lucide-react";
import {
  translations,
  type Language,
  type TranslationKey,
} from "./translations";

type Page =
  | "dashboard"
  | "courses"
  | "challenges"
  | "aiTutor"
  | "achievements"
  | "vip"
  | "profile"
  | "settings";

type Course = {
  id: number;
  title: string;
  description: string;
  category: string;
  icon: typeof Code2;
  color: string;
  lessons: number;
  duration: string;
  xp: number;
  vip: boolean;
  progress: number;
};

const initialCourses: Course[] = [
  {
    id: 1,
    title: "Programming Fundamentals",
    description: "Build your first programming skills, one step at a time.",
    category: "Programming",
    icon: Code2,
    color: "orange",
    lessons: 12,
    duration: "3 hours",
    xp: 120,
    vip: false,
    progress: 35,
  },
  {
    id: 2,
    title: "AI Tools & Productivity",
    description: "Discover how AI can help you learn and create faster.",
    category: "Artificial Intelligence",
    icon: Bot,
    color: "purple",
    lessons: 10,
    duration: "2.5 hours",
    xp: 150,
    vip: false,
    progress: 0,
  },
  {
    id: 3,
    title: "UI/UX Design",
    description: "Learn the foundations of beautiful digital experiences.",
    category: "Design",
    icon: Palette,
    color: "pink",
    lessons: 14,
    duration: "4 hours",
    xp: 180,
    vip: true,
    progress: 0,
  },
  {
    id: 4,
    title: "Social Media Marketing",
    description: "Create content and understand digital audiences.",
    category: "Marketing",
    icon: Megaphone,
    color: "blue",
    lessons: 9,
    duration: "2 hours",
    xp: 100,
    vip: false,
    progress: 0,
  },
  {
    id: 5,
    title: "Video Production",
    description: "Turn your ideas into engaging videos.",
    category: "Creative",
    icon: Video,
    color: "green",
    lessons: 11,
    duration: "3.5 hours",
    xp: 140,
    vip: true,
    progress: 0,
  },
  {
    id: 6,
    title: "Advanced Web Development",
    description: "Explore modern tools for building websites.",
    category: "Programming",
    icon: Globe,
    color: "orange",
    lessons: 16,
    duration: "5 hours",
    xp: 220,
    vip: true,
    progress: 0,
  },
];

const categories = [
  "All",
  "Programming",
  "Artificial Intelligence",
  "Design",
  "Marketing",
  "Creative",
];

const pageIcons: Record<Page, typeof LayoutDashboard> = {
  dashboard: LayoutDashboard,
  courses: BookOpen,
  challenges: Target,
  aiTutor: Bot,
  achievements: Trophy,
  vip: Crown,
  profile: UserRound,
  settings: Settings,
};

const pageLabels: Record<Page, string> = {
  dashboard: "Dashboard",
  courses: "Courses",
  challenges: "Challenges",
  aiTutor: "AI Tutor",
  achievements: "Achievements",
  vip: "Nexiq VIP",
  profile: "My Profile",
  settings: "Settings",
};

function translatedCourseTitle(
  course: Course,
  language: Language,
): string {
  if (language !== "hy") return course.title;

  const titles: Record<number, string> = {
    1: "Ծրագրավորման հիմունքներ",
    2: "AI գործիքներ և արդյունավետություն",
    3: "UI/UX դիզայն",
    4: "Սոցիալական մեդիա մարքեթինգ",
    5: "Վիդեոարտադրություն",
    6: "Վեբ ծրագրավորում՝ առաջադեմ",
  };

  return titles[course.id] ?? course.title;
}
const armenianText: Record<string, string> = {
  "Dashboard": "Գլխավոր",
  "Courses": "Դասընթացներ",
  "Challenges": "Մարտահրավերներ",
  "AI Tutor": "AI օգնական",
  "Achievements": "Նվաճումներ",
  "My Profile": "Իմ հաշիվը",
  "Settings": "Կարգավորումներ",
  "Home": "Գլխավոր",
  "Quests": "Առաջադրանքներ",
  "Profile": "Պրոֆիլ",


  "Programming Fundamentals": "Ծրագրավորման հիմունքներ",
  "Build your first programming skills, one step at a time.": "Սովորիր ծրագրավորման հիմունքները՝ քայլ առ քայլ։",
  "AI Tools & Productivity": "AI գործիքներ և արդյունավետություն",
  "Discover how AI can help you learn and create faster.": "Բացահայտիր, թե ինչպես կարող է AI-ն օգնել քեզ ավելի արագ սովորել և ստեղծագործել։",
  "UI/UX Design": "UI/UX դիզայն",
  "Learn the foundations of beautiful digital experiences.": "Սովորիր գեղեցիկ թվային փորձառություններ ստեղծելու հիմունքները։",
  "Social Media Marketing": "Սոցիալական մեդիայի մարքեթինգ",
  "Create content and understand digital audiences.": "Ստեղծիր բովանդակություն և հասկացիր թվային լսարանի կարիքները։",
  "Video Production": "Տեսանյութերի ստեղծում",
  "Turn your ideas into engaging videos.": "Գաղափարներդ վերածիր հետաքրքիր տեսանյութերի։",
  "Advanced Web Development": "Վեբ ծրագրավորման առաջադեմ դասընթաց",
  "Explore modern tools for building websites.": "Բացահայտիր կայքեր ստեղծելու ժամանակակից գործիքները։",
  "All": "Բոլորը",
  "3 hours": "3 ժամ",
  "2.5 hours": "2.5 ժամ",
  "4 hours": "4 ժամ",
  "2 hours": "2 ժամ",
  "3.5 hours": "3.5 ժամ",
  "5 hours": "5 ժամ",


  "YOUR NEXT LEVEL STARTS HERE": "ՔՈ ՀԱՋՈՐԴ ՄԱԿԱՐԴԱԿԸ ՍԿՍՎՈՒՄ Է ԱՅՍՏԵՂ",
  "Learn smarter.": "Սովորիր ավելի խելացի։",
  "Become unstoppable.": "Շարունակիր զարգանալ։",
  "Build real-world skills, complete challenges, and turn your progress into achievements.":
    "Զարգացրու գործնական հմտություններդ, կատարիր առաջադրանքներ և հասիր նոր նվաճումների։",
  "Explore courses": "Բացահայտել դասընթացները",
  "Daily challenge": "Օրվա մարտահրավեր",
  "Total earned": "Ընդհանուր վաստակ",
  "Rising learner": "Զարգացող սովորող",
  "Total XP": "Ընդհանուր XP",
  "Keep moving forward": "Շարունակիր առաջ շարժվել",
  "My courses": "Իմ դասընթացները",
  "Learning in progress": "Ընթացիկ ուսուցում",
  "Day streak": "Անընդմեջ օրեր",
  "3 days": "3 օր",
  "Consistency wins": "Կանոնավորությունն արդյունք է տալիս",
  "Keep growing, one step at a time.": "Զարգացիր՝ մեկ քայլով։",

  "YOUR JOURNEY": "ՔՈ ՈՒՂԻՆ",
  "Level 4 — Rising Learner": "Մակարդակ 4 — Զարգացող սովորող",
  "Every lesson takes you further.": "Յուրաքանչյուր դաս քեզ առաջ է տանում։",
  "XP to next level": "XP մինչև հաջորդ մակարդակ",
  "HANDPICKED FOR YOU": "ԸՆՏՐՎԱԾ ՔԵԶ ՀԱՄԱՐ",
  "Featured courses": "Ընտրված դասընթացներ",
  "Skills worth investing your time in.": "Հմտություններ, որոնց վրա արժե ժամանակ տրամադրել։",
  "View all": "Դիտել բոլորը",
  "DAILY QUEST": "ՕՐՎԱ ԱՌԱՋԱԴՐԱՆՔ",
  "Small steps. Big progress.": "Փոքր քայլեր։ Մեծ առաջընթաց։",
  "Complete daily tasks and earn XP while building your skills.":
    "Կատարիր ամենօրյա առաջադրանքներ, վաստակիր XP և զարգացրու հմտություններդ։",
  "View challenges": "Դիտել առաջադրանքները",
  "YOUR AI COMPANION": "ՔՈ AI ՕԳՆԱԿԱՆԸ",
  "Questions welcome.": "Հարցերդ ողջունելի են։",
  "Explore ideas, clarify concepts, and keep your curiosity alive.":
    "Բացահայտիր գաղափարներ, հասկացիր բարդ թեմաները և պահպանիր հետաքրքրասիրությունդ։",
  "Meet AI Tutor": "Ծանոթանալ AI օգնականին",
  "GO BEYOND THE BASICS": "ԱՆՑԻՐ ՀԻՄՈՒՆՔՆԵՐԻՑ ԱՅՆ ԿՈՂՄ",
  "Unlock your full potential.": "Բացահայտիր քո ամբողջ ներուժը։",
  "Discover exclusive courses and a more powerful learning journey.":
    "Բացահայտիր հատուկ դասընթացներ և զարգացիր նոր մակարդակում։",
  "Discover VIP": "Բացահայտել VIP-ը",

  "YOUR LEARNING LIBRARY": "ՔՈ ՈՒՍՈՒՄՆԱԿԱՆ ԳՐԱԴԱՐԱՆԸ",
  "Find your next skill and learn at your own pace.":
    "Գտիր հաջորդ հմտությունդ և սովորիր քեզ հարմար տեմպով։",
  "Search courses...": "Փնտրել դասընթաց...",
  "Programming": "Ծրագրավորում",
  "Artificial Intelligence": "Արհեստական բանականություն",
  "Design": "Դիզայն",
  "Marketing": "Մարքեթինգ",
  "Creative": "Ստեղծագործական",
  "No courses found": "Դասընթացներ չեն գտնվել",
  "Try a different search or category.":
    "Փորձիր որոնման այլ բառ կամ բաժին։",
  "Clear filters": "Մաքրել ֆիլտրերը",
  "Back to courses": "Վերադառնալ դասընթացներին",
  "LEARN SOMETHING NEW": "ՍՈՎՈՐԻՐ ՆՈՐ ԲԱՆ",
  "COURSE CONTENT": "ԴԱՍԸՆԹԱՑԻ ԲՈՎԱՆԴԱԿՈՒԹՅՈՒՆԸ",
  "Your learning path": "Քո ուսումնական ուղին",
  "Introduction and key concepts": "Ներածություն և հիմնական գաղափարներ",
  "Understand the fundamentals": "Հասկացիր հիմունքները",
  "Practice with a guided example": "Փորձիր օրինակով",
  "Test your knowledge": "Ստուգիր գիտելիքներդ",
  "Start learning": "Սկսել սովորել",

  "DAILY QUESTS": "ԱՄԵՆՕՐՅԱ ԱՌԱՋԱԴՐԱՆՔՆԵՐ",
  "Challenge yourself": "Մարտահրավեր նետիր քեզ",
  "Build a learning habit with small, achievable actions.":
    "Սովորելու սովորություն ձևավորիր փոքր ու իրագործելի քայլերով։",
  "TODAY'S MISSION": "ԱՅՍՕՐՎԱ ԱՌԱՋԱԴՐԱՆՔԸ",
  "Progress over perfection.": "Կարևորը առաջընթացն է։",
  "Complete your tasks and collect bonus XP.":
    "Կատարիր առաջադրանքները և վաստակիր լրացուցիչ XP։",
  "Today's progress": "Այսօրվա առաջընթացը",
  "Learn something new": "Սովորիր նոր բան",
  "Spend 10 minutes exploring a new topic.":
    "10 րոպե տրամադրիր նոր թեմա ուսումնասիրելուն։",
  "Ask a great question": "Տուր հետաքրքիր հարց",
  "Use your curiosity to explore an idea.":
    "Հետաքրքրասիրությամբդ բացահայտիր նոր գաղափար։",
  "Think like a creator": "Մտածիր ստեղծագործողի պես",
  "Write down one idea for a project.":
    "Գրի առ մեկ գաղափար նախագծի համար։",
  "Complete": "Կատարել",

  "YOUR PERSONAL LEARNING COMPANION": "ՔՈ ԱՆՁՆԱԿԱՆ ՈՒՍՈՒՄՆԱԿԱՆ ՕԳՆԱԿԱՆԸ",
  "Ask questions, explore ideas, and make difficult topics easier.":
    "Տուր հարցեր, ուսումնասիրիր գաղափարներ և ավելի հեշտ հասկացիր բարդ թեմաները։",
  "Learning assistant demo": "Ուսումնական օգնականի ցուցադրական տարբերակ",
  "Hey, learner!": "Ողջո՛ւյն, սովորո՛ղ։",
  "I'm here to help you understand new concepts. Ask me about programming, design, AI, or anything you're learning.":
    "Ես այստեղ եմ՝ նոր գաղափարները հասկանալուդ օգնելու համար։ Հարցրու ծրագրավորման, դիզայնի, AI-ի կամ քո սովորած ցանկացած թեմայի մասին։",
  "Ask your learning question...": "Գրիր ուսումնական հարցդ...",
  "Questions asked in this session": "Այս ընթացքում տրված հարցերը",
  "Explain a concept": "Բացատրել գաղափարը",
  "Break down a difficult idea into simple steps.":
    "Բարդ գաղափարը բաժանել պարզ քայլերի։",
  "Practice a skill": "Վարժվել հմտության մեջ",
  "Try examples and strengthen your understanding.":
    "Փորձել օրինակներ և ամրապնդել գիտելիքները։",

  "YOUR MILESTONES": "ՔՈ ՆՎԱՃՈՒՄՆԵՐԸ",
  "Every small win is a step toward something bigger.":
    "Յուրաքանչյուր փոքր հաջողություն քայլ է դեպի մեծ նպատակը։",
  "COLLECTION PROGRESS": "ՆՎԱՃՈՒՄՆԵՐԻ ԱՌԱՋԸՆԹԱՑԸ",
  "First Steps": "Առաջին քայլերը",
  "Start your learning journey.": "Սկսիր քո ուսումնական ուղին։",
  "Curious Mind": "Հետաքրքրասեր միտք",
  "Explore your first course.": "Բացահայտիր առաջին դասընթացդ։",
  "Quest Starter": "Առաջադրանքի մեկնարկ",
  "Complete your first challenge.": "Կատարիր առաջին մարտահրավերդ։",
  "XP Collector": "XP հավաքող",
  "Earn 500 XP.": "Վաստակիր 500 XP։",
  "Consistent Learner": "Հետևողական սովորող",
  "Keep your learning streak alive.": "Շարունակիր սովորել ամեն օր։",
  "VIP Explorer": "VIP հետազոտող",
  "Discover the VIP learning path.": "Բացահայտիր VIP ուսումնական ուղին։",
  "UNLOCKED": "ԲԱՑՎԱԾ Է",

  "THE NEXT LEVEL": "ՀԱՋՈՐԴ ՄԱԿԱՐԴԱԿԸ",
  "Explore the possibilities of a more advanced learning experience.":
    "Բացահայտիր ավելի առաջադեմ ուսուցման հնարավորությունները։",
  "More skills. More possibilities.": "Ավելի շատ հմտություններ։ Ավելի շատ հնարավորություններ։",
  "Exclusive courses": "Հատուկ դասընթացներ",
  "Explore advanced learning paths.": "Բացահայտիր առաջադեմ ուսումնական ուղիները։",
  "Deeper learning": "Ավելի խոր ուսուցում",
  "Build on your skills with focused lessons.":
    "Զարգացրու հմտություններդ նպատակային դասերով։",
  "More challenges": "Ավելի շատ առաջադրանքներ",
  "Discover additional ways to practice.":
    "Բացահայտիր վարժվելու նոր եղանակներ։",
  "Learning milestones": "Ուսումնական նվաճումներ",
  "Keep track of your progress.": "Հետևիր քո առաջընթացին։",

  "YOUR PERSONAL SPACE": "ՔՈ ԱՆՁՆԱԿԱՆ ՏԱՐԱԾՔԸ",
  "Your learning identity and progress, all in one place.":
    "Քո ուսումնական տվյալներն ու առաջընթացը՝ մեկ տեղում։",
  "Future Creator": "Ապագա ստեղծող",
  "Nexiq learner since today": "Nexiq-ի սովորող՝ այսօրվանից",
  "Courses started": "Սկսած դասընթացներ",
  "YOUR LEARNING": "ՔՈ ՈՒՍՈՒՑՈՒՄԸ",
  "Continue your journey": "Շարունակիր քո ուղին",
  "Account preferences": "Հաշվի կարգավորումներ",
  "Manage your app settings": "Կառավարիր հավելվածի կարգավորումները",

  "MAKE IT YOURS": "ԿԱՐԳԱՎՈՐԻՐ ՔԵԶ ՀԱՄԱՐ",
  "Choose how Nexiq works for you.": "Ընտրիր, թե ինչպես աշխատի Nexiq-ը քեզ համար։",
  "App language": "Հավելվածի լեզուն",
  "Choose your preferred language.": "Ընտրիր նախընտրած լեզուդ։",
  "Learning experience": "Ուսուցման փորձառություն",
  "Personalized recommendations are in demo mode.":
    "Անհատական առաջարկներն առայժմ ցուցադրական ռեժիմում են։",
  "Privacy and security": "Գաղտնիություն և անվտանգություն",
  "Authentication and account controls will be added later.":
    "Մուտքի և հաշվի կառավարման գործիքները կավելացվեն ավելի ուշ։",
  "AI responses are currently simulated.":
    "AI պատասխաններն առայժմ ցուցադրական են։",
  "Open": "Բացել",
  "WORKSPACE": "ԱՇԽԱՏԱՆՔԱՅԻՆ ՏԱՐԱԾՔ",
  "YOUR ACCOUNT": "ՔՈ ՀԱՇԻՎԸ",
  "Unlock Nexiq VIP": "Բացահայտիր Nexiq VIP-ը",
  "Take your skills further": "Զարգացրու հմտություններդ",
  "LANGUAGE": "ԼԵԶՈՒ",
  "WELCOME BACK": "ԲԱՐԻ ԳԱԼՈՒՍՏ",
  "Ready to evolve?": "Պատրա՞ստ ես զարգանալու",
};

function LocalizedUI({
  language,
  children,
}: {
  language: Language;
  children: ReactNode;
}) {
  const translateNode = (node: ReactNode): ReactNode => {
    if (typeof node === "string") {
      if (language !== "hy") return node;

      const trimmed = node.trim();
      const translated = armenianText[trimmed];

      return translated
        ? node.replace(trimmed, translated)
        : node;
    }

    if (Array.isArray(node)) {
      return Children.map(node, translateNode);
    }

if (isValidElement<{ children?: ReactNode; placeholder?: string; "aria-label"?: string; title?: string }>(node)) {
  const props = node.props;

  const translatedChildren = translateNode(props.children);

  if (node.type === Fragment) {
    return (
      <Fragment>
        {translatedChildren}
      </Fragment>
    );
  }

  const translateAttribute = (value?: string) =>
    language === "hy" && value
      ? armenianText[value] ?? value
      : value;

  return cloneElement(node, {
    ...props,
    placeholder: translateAttribute(props.placeholder),
    "aria-label": translateAttribute(props["aria-label"]),
    title: translateAttribute(props.title),
  }, translatedChildren);
}

return node;

  };

  return <>{translateNode(children)}</>;
}
function App() {
  const routerNavigate = useNavigate();

  type CompletedLessons = Record<number, number[]>;

const [completedLessons, setCompletedLessons] =
  useState<CompletedLessons>(() => {
    try {
      const saved = localStorage.getItem("nexiq-completed-lessons");
      return saved ? JSON.parse(saved) as CompletedLessons : {};
    } catch {
      return {};
    }
  });

const [activeLessonIndex, setActiveLessonIndex] = useState(0);

useEffect(() => {
  localStorage.setItem(
    "nexiq-completed-lessons",
    JSON.stringify(completedLessons),
  );
}, [completedLessons]);

const getCourseProgress = (courseId: number) => {
  const course = initialCourses.find((item) => item.id === courseId);
  if (!course) return 0;

  const totalLessons = course.id === 1 ? 4 : 4;
  const completed = completedLessons[courseId]?.length ?? 0;

  return Math.round((completed / totalLessons) * 100);
};

const finishLesson = (course: Course, lessonIndex: number) => {
  const alreadyCompleted =
    completedLessons[course.id]?.includes(lessonIndex) ?? false;

  if (alreadyCompleted) {
    showNotice(
      language === "hy"
        ? "Այս դասն արդեն ավարտել ես։"
        : "You have already completed this lesson.",
    );
    return;
  }

  setCompletedLessons((previous) => ({
    ...previous,
    [course.id]: [
      ...(previous[course.id] ?? []),
      lessonIndex,
    ],
  }));

  setXp((previous) => previous + 25);

  showNotice(
    language === "hy"
      ? "Դասն ավարտված է։ +25 XP"
      : "Lesson completed! +25 XP",
  );
};
  const [savedCompletedLessons, setSavedCompletedLessons] =
  useState<string[]>(() => getCompletedLessons());
  const [language, setLanguage] = useState<Language>("hy");
  const [page, setPage] = useState<Page>("dashboard");
  const [menuOpen, setMenuOpen] = useState(false);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [notice, setNotice] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [aiCount, setAiCount] = useState(0);
  const [completedChallenges, setCompletedChallenges] = useState<number[]>([]);
  const [xp, setXp] = useState(340);

  const t = (key: TranslationKey): string => {
  return translations[language][key] ?? String(key);
  };

  const courses = initialCourses;

  const filteredCourses = useMemo(() => {
    const normalizedSearch = search.toLowerCase().trim();

    return courses.filter((course) => {
      const matchesCategory =
        category === "All" || course.category === category;

      const matchesSearch =
        !normalizedSearch ||
        course.title.toLowerCase().includes(normalizedSearch) ||
        course.description.toLowerCase().includes(normalizedSearch) ||
        course.category.toLowerCase().includes(normalizedSearch);

      return matchesCategory && matchesSearch;
    });
  }, [courses, category, search]);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2800);
  };

  const navigate = (nextPage: Page) => {
    setPage(nextPage);
    setSelectedCourse(null);
    setMenuOpen(false);
  };

  const startCourse = (course: Course) => {
    if (course.vip) {
      showNotice(
        language === "hy"
          ? "Այս դասընթացի համար անհրաժեշտ է VIP անդամակցություն։"
          : "This course requires VIP membership.",
      );
      navigate("vip");
      return;
    }

    setSelectedCourse(course);
  };

  const completeChallenge = (id: number) => {
    if (completedChallenges.includes(id)) return;

    setCompletedChallenges((previous) => [...previous, id]);
    setXp((previous) => previous + 25);
    showNotice(
      language === "hy"
        ? "Մարտահրավերը կատարված է։ +25 XP"
        : "Challenge completed! +25 XP",
    );
  };

  const askAI = () => {
    if (!question.trim()) return;

    setAiCount((previous) => previous + 1);
    setAnswer(
      language === "hy"
        ? `Լավ հարց է։ «${question.trim()}» թեման սովորելու համար բաժանիր այն փոքր քայլերի։ Նախ հասկացիր հիմնական գաղափարը, հետո փորձիր փոքր օրինակ և վերջում բացատրիր այն քո բառերով։ Սա Nexiq AI Tutor-ի ցուցադրական պատասխանն է։`
        : `Great question! To learn about "${question.trim()}", break it into smaller steps. First understand the core idea, then try a small example, and finally explain it in your own words. This is a demo response from Nexiq AI Tutor.`,
    );
    setQuestion("");
  };

  const renderCourseCard = (course: Course) => {
    const Icon = course.icon;

    return (
      <article className="course-card" key={course.id}>
        <div className={`course-art ${course.color}`}>
          <div className="course-art-top">
            <span className="course-category">{course.category}</span>
            <span className={course.vip ? "vip-badge" : "free-badge"}>
              {course.vip ? (
                <>
                  <Crown size={12} /> VIP
                </>
              ) : (
                "FREE"
              )}
            </span>
          </div>

          <div className="course-art-icon">
            <Icon size={42} strokeWidth={1.6} />
          </div>

          <span className="art-index">
            NEXIQ / {String(course.id).padStart(2, "0")}
          </span>
        </div>

        <div className="course-content">
          <div className="course-meta">
            <span>
              <BookOpen size={14} /> {course.lessons} lessons
            </span>
            <span>
              <Zap size={14} /> {course.xp} XP
            </span>
          </div>

          <h3>{translatedCourseTitle(course, language)}</h3>
          <p>{course.description}</p>

          {getCourseProgress(course.id) > 0 && (
            <div className="course-progress">
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{
                    width: `${getCourseProgress(course.id)}%`,
                  }}
                />
              </div>
              <span>{getCourseProgress(course.id)}% complete</span>
            </div>
          )}

          <button
            className={`course-action ${course.vip ? "locked-action" : ""}`}
            onClick={() => startCourse(course)}
          >
            {course.vip ? (
              <>
                <LockKeyhole size={15} /> Explore VIP
              </>
            ) : (
              <>
                {t("continueLearning")} <ArrowUpRight size={16} />
              </>
            )}
          </button>
        </div>
      </article>
    );
  };

  const renderHeading = (
    eyebrow: string,
    title: string,
    description: string,
  ) => (
    <div className="page-heading">
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      <p>{description}</p>
    </div>
  );

  const renderDashboard = () => (
    <>

    <section className="hero">
      <div className="hero-content">
        <div className="hero-proof">
          <span className="live-dot" />
          {language === "hy"
            ? "ՔՈ ՆՈՐ ՄԱԿԱՐԴԱԿԸ ՍԿՍՎՈՒՄ Է ԱՅՍՏԵՂ"
            : "YOUR NEXT LEVEL STARTS HERE"}
        </div>

          <h1>
            Learn smarter.
            <br />
            <span>Become unstoppable.</span>
          </h1>
          <p>
            Build real-world skills, complete challenges, and turn your
            progress into achievements.
          </p>
          <div className="hero-actions">
            <button
              className="button-primary"
              onClick={() => navigate("courses")}
            >
              Explore courses <ArrowRight size={17} />
            </button>
            <button
              className="button-secondary"
              onClick={() => navigate("challenges")}
            >
              <Target size={17} /> Daily challenge
            </button>
          </div>
          <div className="hero-caption">
            <Sparkles size={15} />
            Learn. Earn. Evolve.
          </div>
        </div>

        <div className="hero-visual" aria-hidden="true">
          <div className="visual-ring ring-one" />
          <div className="visual-ring ring-two" />
          <div className="visual-core">
            <GraduationCap size={54} />
            <span>NEXIQ</span>
          </div>
          <div className="floating-card floating-xp">
            <Zap size={17} />
            <div>
              <strong>{xp} XP</strong>
              <small>Total earned</small>
            </div>
          </div>
          <div className="floating-card floating-level">
            <Trophy size={18} />
            <div>
              <strong>Level 4</strong>
              <small>Rising learner</small>
            </div>
          </div>
          <span className="visual-dot dot-one" />
          <span className="visual-dot dot-two" />
        </div>
      </section>

      <section className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon orange">
            <Zap size={20} />
          </div>
          <div>
            <span className="stat-label">Total XP</span>
            <strong>{xp.toLocaleString()}</strong>
            <small>Keep moving forward</small>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">
            <BookOpen size={20} />
          </div>
          <div>
            <span className="stat-label">My courses</span>
            <strong>2</strong>
            <small>Learning in progress</small>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">
            <Flame size={20} />
          </div>
          <div>
            <span className="stat-label">Day streak</span>
            <strong>3 days</strong>
            <small>Consistency wins</small>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">
            <Trophy size={20} />
          </div>
          <div>
            <span className="stat-label">Challenges</span>
            <strong>{completedChallenges.length}/3</strong>
            <small>Daily progress</small>
          </div>
        </div>
      </section>

      <section className="level-card">
        <div className="level-heading">
          <div className="level-avatar">
            <GraduationCap size={24} />
          </div>
          <div>
            <span className="eyebrow">YOUR JOURNEY</span>
            <h3>Level 4 — Rising Learner</h3>
            <p>Every lesson takes you further.</p>
          </div>
          <span className="level-xp">{xp} / 500 XP</span>
        </div>
        <div className="progress-track">
          <div
            className="progress-fill"
            style={{ width: `${Math.min((xp / 500) * 100, 100)}%` }}
          />
        </div>
        <div className="progress-labels">
          <span>Level 4</span>
          <span>{Math.max(500 - xp, 0)} XP to next level</span>
        </div>
      </section>

      <section className="page-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">HANDPICKED FOR YOU</span>
            <h2>Featured courses</h2>
            <p>Skills worth investing your time in.</p>
          </div>
          <button className="text-link" onClick={() => navigate("courses")}>
            View all <ArrowRight size={16} />
          </button>
        </div>
        <div className="course-grid">
          {courses.slice(0, 3).map(renderCourseCard)}
        </div>
      </section>

      <section className="feature-grid">
        <article className="feature-card challenge-feature">
          <div className="feature-icon">
            <Target size={23} />
          </div>
          <span className="feature-eyebrow">DAILY QUEST</span>
          <h3>Small steps. Big progress.</h3>
          <p className="feature-description">
            Complete daily tasks and earn XP while building your skills.
          </p>
          <button className="feature-link" onClick={() => navigate("challenges")}>
            View challenges <ArrowRight size={16} />
          </button>
        </article>

        <article className="feature-card ai-feature">
          <div className="feature-icon">
            <Bot size={23} />
          </div>
          <span className="feature-eyebrow">YOUR AI COMPANION</span>
          <h3>Questions welcome.</h3>
          <p className="feature-description">
            Explore ideas, clarify concepts, and keep your curiosity alive.
          </p>
          <button className="feature-link" onClick={() => navigate("aiTutor")}>
            Meet AI Tutor <ArrowRight size={16} />
          </button>
        </article>
      </section>

      <section className="vip-banner">
        <div className="vip-banner-icon">
          <Crown size={27} />
        </div>
        <div className="vip-banner-copy">
          <span className="eyebrow">GO BEYOND THE BASICS</span>
          <h2>Unlock your full potential.</h2>
          <p>Discover exclusive courses and a more powerful learning journey.</p>
        </div>
        <button className="button-primary" onClick={() => navigate("vip")}>
          Discover VIP <ArrowRight size={16} />
        </button>
      </section>
    </>
  );

  const renderCourses = () => (
    <>
      {renderHeading(
        "YOUR LEARNING LIBRARY",
        "Explore courses",
        "Find your next skill and learn at your own pace.",
      )}

      <div className="course-toolbar">
        <label className="search-box">
          <Search size={18} />
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search courses..."
          />
          {search && (
            <button
              className="icon-button"
              aria-label="Clear search"
              onClick={() => setSearch("")}
            >
              <X size={16} />
            </button>
          )}
        </label>
        <span className="course-count">{filteredCourses.length} courses</span>
      </div>

      <div className="category-list">
        {categories.map((item) => (
          <button
            key={item}
            className={`category-chip ${category === item ? "active" : ""}`}
            onClick={() => setCategory(item)}
          >
            {item}
          </button>
        ))}
      </div>

      {filteredCourses.length ? (
        <div className="course-grid">
          {filteredCourses.map(renderCourseCard)}
        </div>
      ) : (
        <div className="empty-state">
          <Search size={30} />
          <h3>No courses found</h3>
          <p>Try a different search or category.</p>
          <button
            className="button-secondary"
            onClick={() => {
              setSearch("");
              setCategory("All");
            }}
          >
            Clear filters
          </button>
        </div>
      )}
    </>
  );


const renderCourseDetail = () => {
  if (!selectedCourse) return null;

  const Icon = selectedCourse.icon;

  const lessonContent: Record<number, string[]> =
    language === "hy"
      ? {
          1: [
            "Ծրագրավորման ներածություն",
            "Փոփոխականներ և տվյալների տեսակներ",
            "Պայմաններ և ցիկլեր",
            "Գործնական առաջադրանք",
          ],
          2: [
            "Ծանոթություն AI գործիքներին",
            "AI-ի արդյունավետ օգտագործում",
            "Աշխատանքի ավտոմատացում",
            "Ստեղծիր քո առաջին AI նախագիծը",
          ],
          3: [
            "UI/UX դիզայնի հիմունքներ",
            "Գույներ և տառատեսակներ",
            "Օգտատիրոջ փորձառություն",
            "Նախագծիր քո առաջին էջը",
          ],
          4: [
            "Թվային մարքեթինգի հիմունքներ",
            "Սոցիալական մեդիայի ռազմավարություն",
            "Բովանդակության ստեղծում",
            "Կազմիր մարքեթինգային պլան",
          ],
          5: [
            "Տեսանյութերի ստեղծման հիմունքներ",
            "Նկարահանում և կադրեր",
            "Մոնտաժի հիմունքներ",
            "Ստեղծիր քո առաջին տեսանյութը",
          ],
          6: [
            "Վեբ ծրագրավորման հիմունքներ",
            "Ժամանակակից վեբ գործիքներ",
            "Կայքի կառուցվածք և ոճավորում",
            "Ստեղծիր քո սեփական կայքը",
          ],
        }
      : {
          1: [
            "Introduction to Programming",
            "Variables and Data Types",
            "Conditions and Loops",
            "Practical Challenge",
          ],
          2: [
            "Introduction to AI Tools",
            "Using AI Effectively",
            "Workflow Automation",
            "Build Your First AI Project",
          ],
          3: [
            "UI/UX Design Fundamentals",
            "Colors and Typography",
            "User Experience",
            "Design Your First Screen",
          ],
          4: [
            "Digital Marketing Basics",
            "Social Media Strategy",
            "Content Creation",
            "Build a Marketing Plan",
          ],
          5: [
            "Video Production Basics",
            "Filming and Composition",
            "Video Editing Fundamentals",
            "Create Your First Video",
          ],
          6: [
            "Web Development Fundamentals",
            "Modern Web Tools",
            "Website Structure and Styling",
            "Build Your Own Website",
          ],
        };

  const lessons = lessonContent[selectedCourse.id] ?? [];


  const progressLessonIds = [
    "programming-intro",
    "variables",
    "conditions",
    "practice",
  ];

  const completedCount = lessons.reduce((count, _, index) => {
    const savedComplete =
      selectedCourse.id === 1 &&
      savedCompletedLessons.includes(progressLessonIds[index]);

    return count + (
      completedForCourse.includes(index) || savedComplete ? 1 : 0
    );
  }, 0);

  const progressPercent =
    lessons.length > 0
      ? Math.round((completedCount / lessons.length) * 100)
      : 0;


  const lessonExplanations: Record<number, string[]> =
  language === "hy"
    ? {
        1: [
          "Ծրագրավորումը համակարգչին հրահանգներ տալու գործընթացն է։ Օրինակ՝ կարող ես ստեղծել ծրագիր, որը հաշվում է երկու թվերի գումարը։",
          "Փոփոխականը տվյալ պահելու տեղ է։ JavaScript-ում՝ const name = 'Անի';։ Տվյալների տեսակների օրինակներ են տեքստը, թիվը և true/false արժեքները։",
          "if պայմանը թույլ է տալիս որոշում կայացնել, իսկ ցիկլը՝ կրկնել գործողությունները։ Օրինակ՝ if (age >= 18) ստուգում է տարիքը։",
          "Փորձիր գրել մի փոքր ծրագիր, որը պահում է քո անունը և տպում ողջույնի հաղորդագրություն։",
        ],
        2: [
          "Արհեստական բանականության գործիքները կարող են օգնել սովորել, գրել, վերլուծել և ստեղծագործել։",
          "Հստակ նշիր խնդիրը, տրամադրիր անհրաժեշտ համատեքստ և խնդրիր կոնկրետ արդյունք։ Ստուգիր ստացված պատասխանը։",
          "Ավտոմատացումը կրկնվող աշխատանքը կատարում է նախապես սահմանված քայլերով։ Նախ որոշիր՝ որ աշխատանքն է պետք պարզեցնել։",
          "Մտածիր մի փոքր նախագծի մասին, որտեղ AI-ն օգնում է լուծել կոնկրետ խնդիր։ Գրիր նպատակը և քայլերը։",
        ],
        3: [
          "UI-ն էջի տեսանելի մասն է, իսկ UX-ը՝ այն օգտագործելու ամբողջ փորձառությունը։",
          "Ընտրիր իրար համապատասխանող գույներ և հեշտ ընթերցվող տառատեսակներ։ Պահպանիր վերնագրերի ու տեքստերի հստակ տարբերությունը։",
          "Լավ օգտատիրոջ փորձառությունը նշանակում է, որ մարդը հեշտությամբ գտնում է անհրաժեշտ տեղեկությունը և կատարում իր նպատակը։",
          "Նախագծիր մեկ էջ՝ վերնագրով, նկարագրությամբ և հստակ գործողության կոճակով։",
        ],
        4: [
          "Թվային մարքեթինգը համացանցի միջոցով մարդկանց տեղեկացնելու և նրանց հետ կապ ստեղծելու միջոց է։",
          "Ընտրիր հարթակը՝ ըստ լսարանի և նպատակի։ Յուրաքանչյուր հրապարակման համար նախապես որոշիր նպատակը։",
          "Օգտակար բովանդակությունը պետք է համապատասխանի լսարանի հետաքրքրություններին և ներկայացվի հասկանալի ձևով։",
          "Կազմիր մեկշաբաթյա պլան՝ նշելով հրապարակման թեման, հարթակը և նպատակը։",
        ],
        5: [
          "Տեսանյութի ստեղծումը սկսվում է գաղափարից, նպատակից և կարճ պլանից։",
          "Մտածիր լուսավորության, կադրի և ձայնի մասին։ Հստակ կադրը օգնում է դիտողին հասկանալ ասելիքը։",
          "Մոնտաժի ընթացքում ընտրիր անհրաժեշտ հատվածները, կարգավորիր հերթականությունը և ավելացրու ընթեռնելի վերնագրեր։",
          "Ստեղծիր կարճ տեսանյութի պլան՝ ներածությամբ, հիմնական մասով և ավարտով։",
        ],
        6: [
          "Վեբ կայքերը հաճախ կառուցվում են HTML-ով, ձևավորվում CSS-ով և դառնում ինտերակտիվ JavaScript-ով։",
          "Ժամանակակից գործիքները օգնում են գրել, փորձարկել և կազմակերպել կոդը։ Ընտրիր գործիքներ՝ ըստ նախագծի կարիքների։",
          "HTML-ը սահմանում է էջի կառուցվածքը, իսկ CSS-ը՝ գույները, չափերը և դասավորությունը։",
          "Ստեղծիր փոքր էջ՝ վերնագրով, նկարագրությամբ և կոճակով։ Այնուհետև ձևավորիր այն CSS-ով։",
        ],
      }
    : {
        1: [
          "Programming is the process of giving instructions to a computer. For example, you can create a program that adds two numbers.",
          "A variable stores data. In JavaScript: const name = 'Ani'; Common data types include text, numbers, and true/false values.",
          "An if statement makes a decision, while a loop repeats an action. For example, if (age >= 18) checks an age.",
          "Try writing a small program that stores your name and prints a greeting.",
        ],
        2: [
          "AI tools can help with learning, writing, analysis, and creative work.",
          "Describe the task clearly, provide context, and ask for a specific result. Always review the answer.",
          "Automation uses predefined steps to handle repetitive work. First identify the task you want to simplify.",
          "Think of a small project where AI could help solve a specific problem. Write down its goal and steps.",
        ],
        3: [
          "UI is the visible interface, while UX is the overall experience of using it.",
          "Choose colors that work well together and readable fonts. Keep headings and body text visually distinct.",
          "Good user experience helps people find information and complete their goals easily.",
          "Design one screen with a heading, description, and clear action button.",
        ],
        4: [
          "Digital marketing uses online channels to inform people and build connections with an audience.",
          "Choose a platform based on your audience and goal. Decide the purpose of each post in advance.",
          "Useful content matches the audience's interests and communicates ideas clearly.",
          "Create a one-week plan with a topic, platform, and goal for each post.",
        ],
        5: [
          "Video production starts with an idea, a goal, and a short plan.",
          "Consider lighting, framing, and sound. A clear shot helps viewers understand your message.",
          "Editing involves selecting clips, arranging them, and adding readable titles when useful.",
          "Plan a short video with an introduction, main section, and ending.",
        ],
        6: [
          "Websites often use HTML for structure, CSS for styling, and JavaScript for interactivity.",
          "Modern tools help you write, test, and organize code. Choose tools that fit your project's needs.",
          "HTML defines page structure, while CSS controls colors, sizes, and layout.",
          "Build a small page with a heading, description, and button, then style it with CSS.",
        ],
      };



const completedForCourse =
  completedLessons[selectedCourse.id] ?? [];

  const labels =
    language === "hy"
      ? {
          back: "Վերադառնալ դասընթացներին",
          banner: "ՍՈՎՈՐԻՐ ՆՈՐ ԲԱՆ",
          lessons: "դաս",
          reward: "XP պարգև",
          content: "ԴԱՍԸՆԹԱՑԻ ԲՈՎԱՆԴԱԿՈՒԹՅՈՒՆ",
          path: "Քո ուսումնական ուղին",
          intro: "ՍԿԻԶԲ",
          free: "Անվճար դաս",
          locked: "VIP դաս",
          start: "Սկսել սովորել",
          demo: "Դասի մեկնարկը դեռ ցուցադրական է։",
        }
      : {
          back: "Back to courses",
          banner: "LEARN SOMETHING NEW",
          lessons: "lessons",
          reward: "XP reward",
          content: "COURSE CONTENT",
          path: "Your learning path",
          intro: "INTRO",
          free: "Free lesson",
          locked: "VIP lesson",
          start: "Start learning",
          demo: "Lesson playback is coming soon.",
        };

  return (
    <section className="course-detail">
      <button
        className="back-button"
        onClick={() => setSelectedCourse(null)}
      >
        <ArrowLeft size={17} /> {labels.back}
      </button>

      <div className={`course-detail-art ${selectedCourse.color}`}>
        <Icon size={64} strokeWidth={1.4} />
        <span>{labels.banner}</span>
      </div>

      <span className="eyebrow">
        {selectedCourse.category}
      </span>

      <h1>{translatedCourseTitle(selectedCourse, language)}</h1>

      <p className="detail-description">
        {selectedCourse.description}
      </p>

      <div className="detail-info">
        <span>
          <BookOpen size={17} />
          {selectedCourse.lessons} {labels.lessons}
        </span>

        <span>
          <Zap size={17} />
          {selectedCourse.xp} {labels.reward}
        </span>

        <span>
          <Play size={17} />
          {selectedCourse.duration}
        </span>
      </div>

      <div className="lesson-preview">
        <div className="lesson-preview-heading">
          <div>
            <span className="eyebrow">{labels.content}</span>
            <h3>{labels.path}</h3>
          </div>

          <span className="free-badge">{labels.intro}</span>
        </div>



        <div
          className="lesson-content"
          key={`${selectedCourse.id}-${activeLessonIndex}`}
        >
          <h2>{lessons[activeLessonIndex]}</h2>

          <p
            className="lesson-explanation"
            style={{
              display: "block",
              visibility: "visible",
              opacity: 1,
              color: "inherit",
              fontSize: "16px",
              lineHeight: 1.8,
              whiteSpace: "normal",
            }}
          >
            {lessonExplanations[selectedCourse.id]?.[activeLessonIndex] ??
              "Այս դասի բացատրությունը դեռ ավելացված չէ։"}
          </p>
        </div>


        {lessons.map((lesson, index) => {
          const isLocked = selectedCourse.vip && index > 0;
          const lessonIds = [
          "programming-intro",
          "variables",
          "conditions",
          "practice",
        ];


        const isCompleted =
          completedForCourse.includes(index) ||
          (selectedCourse.id === 1 &&
            savedCompletedLessons.includes(lessonIds[index]));

          return (
 
          <button
            type="button"
            className="lesson-row"
            key={lesson}
            onClick={() => {
              if (isLocked) {
                showNotice(
                  language === "hy"
                    ? "Այս դասը հասանելի է միայն VIP օգտատերերին։"
                    : "This lesson is available to VIP users only."
                );
                return;
              }

              if (selectedCourse.id === 1) {
                const lessonIds = [
                  "programming-intro",
                  "variables",
                  "conditions",
                  "practice",
                ];

                routerNavigate(`/lesson/${lessonIds[index]}`);
              } else {
                setActiveLessonIndex(index);
              }
            }}
          >

              <span className="lesson-number">
                {String(index + 1).padStart(2, "0")}
              </span>

              <span>{lesson}</span>

              {isLocked ? (
                <LockKeyhole size={15} aria-label={labels.locked} />
              ) : isCompleted ? (
                <Check size={17} color="#22c55e" aria-label="Completed" />
              ) : (
                <Play size={16} aria-label={labels.free} />
              )}
            </button>
          );
        })}

      <button
        className="button-primary full-button"
        disabled={
          (selectedCourse.vip && activeLessonIndex > 0) ||
          completedForCourse.includes(activeLessonIndex)
        }
        onClick={() => {
          if (selectedCourse.vip && activeLessonIndex > 0) {
            showNotice(
              language === "hy"
                ? "Այս դասի համար անհրաժեշտ է VIP։"
                : "VIP is required for this lesson.",
            );
            return;
          }

          finishLesson(selectedCourse, activeLessonIndex);

          if (selectedCourse.id === 1) {
            const programmingLessonIds = [
              "programming-intro",
              "variables",
              "conditions",
              "practice",
            ];

            const completedId = programmingLessonIds[activeLessonIndex];

            if (completedId) {
              completeLesson(completedId);
              setSavedCompletedLessons(getCompletedLessons());
            }
          }

          showNotice(
            language === "hy"
              ? "Դասը հաջողությամբ ավարտվեց։"
              : "Lesson completed successfully.",
          );

          navigate("courses");
        }}
      >
        <Check size={17} />
        {completedForCourse.includes(activeLessonIndex)
          ? language === "hy"
            ? "Դասն ավարտված է"
            : "Lesson completed"
          : language === "hy"
            ? "Ավարտել դասը և շարունակել"
            : "Complete lesson and continue"}
      </button>

      </div>
    </section>
  );
};


  const renderChallenges = () => {
    const challenges = [
      {
        id: 1,
        title: "Learn something new",
        description: "Spend 10 minutes exploring a new topic.",
        reward: 25,
        icon: BookOpen,
      },
      {
        id: 2,
        title: "Ask a great question",
        description: "Use your curiosity to explore an idea.",
        reward: 25,
        icon: MessageCircle,
      },
      {
        id: 3,
        title: "Think like a creator",
        description: "Write down one idea for a project.",
        reward: 25,
        icon: Sparkles,
      },
    ];

    return (
      <>
        {renderHeading(
          "DAILY QUESTS",
          "Challenge yourself",
          "Build a learning habit with small, achievable actions.",
        )}

        <div className="challenge-panel">
          <div className="challenge-panel-top">
            <div className="large-feature-icon"><Target size={31} /></div>
            <div>
              <span className="eyebrow">TODAY'S MISSION</span>
              <h2>Progress over perfection.</h2>
              <p>Complete your tasks and collect bonus XP.</p>
            </div>
          </div>

          <div className="challenge-progress-heading">
            <span>Today's progress</span>
            <strong>{completedChallenges.length} / {challenges.length}</strong>
          </div>
          <div className="progress-track">
            <div
              className="progress-fill"
              style={{
                width: `${(completedChallenges.length / challenges.length) * 100}%`,
              }}
            />
          </div>

          <div className="challenge-list">
            {challenges.map((challenge) => {
              const Icon = challenge.icon;
              const completed = completedChallenges.includes(challenge.id);

              return (
                <article
                  className={`challenge-item ${completed ? "completed" : ""}`}
                  key={challenge.id}
                >
                  <div className="challenge-item-icon"><Icon size={21} /></div>
                  <div className="challenge-item-copy">
                    <h3>{challenge.title}</h3>
                    <p>{challenge.description}</p>
                    <span className="challenge-reward">
                      <Zap size={13} /> +{challenge.reward} XP
                    </span>
                  </div>
                  <button
                    className={`challenge-complete ${completed ? "done" : ""}`}
                    onClick={() => completeChallenge(challenge.id)}
                    disabled={completed}
                  >
                    {completed ? <Check size={17} /> : "Complete"}
                  </button>
                </article>
              );
            })}
          </div>
        </div>
      </>
    );
  };

  const renderAITutor = () => (
    <>
      {renderHeading(
        "YOUR PERSONAL LEARNING COMPANION",
        "AI Tutor",
        "Ask questions, explore ideas, and make difficult topics easier.",
      )}

      <section className="ai-panel">
        <div className="ai-panel-heading">
          <div className="ai-avatar"><Bot size={25} /></div>
          <div>
            <h2>Nexiq AI</h2>
            <p><span className="live-dot" /> Learning assistant demo</p>
          </div>
          <span className="ai-status">DEMO</span>
        </div>

        <div className="ai-conversation">
          <div className="ai-message">
            <div className="ai-message-avatar"><Sparkles size={16} /></div>
            <div className="ai-message-body">
              <strong>Hey, learner!</strong>
              <p>
                I'm here to help you understand new concepts. Ask me about
                programming, design, AI, or anything you're learning.
              </p>
            </div>
          </div>

          {answer && (
            <div className="ai-message">
              <div className="ai-message-avatar"><Bot size={16} /></div>
              <div className="ai-message-body">
                <strong>Nexiq AI</strong>
                <p>{answer}</p>
              </div>
            </div>
          )}
        </div>

        <form
          className="ai-input-row"
          onSubmit={(event) => {
            event.preventDefault();
            askAI();
          }}
        >
          <input
            value={question}
            onChange={(event) => setQuestion(event.target.value)}
            placeholder="Ask your learning question..."
            aria-label="Ask AI Tutor"
          />
          <button
            className="send-button"
            type="submit"
            disabled={!question.trim()}
            aria-label="Send question"
          >
            <Send size={18} />
          </button>
        </form>
        <p className="ai-disclaimer">
          <Sparkles size={13} /> Demo mode: responses are generated locally.
          A real AI API can be connected later.
        </p>

        <div className="ai-usage">
          <span>Questions asked in this session</span>
          <strong>{aiCount}</strong>
        </div>
      </section>

      <div className="feature-grid">
        {[
          ["Explain a concept", "Break down a difficult idea into simple steps."],
          ["Practice a skill", "Try examples and strengthen your understanding."],
        ].map(([title, description]) => (
          <article className="feature-card" key={title}>
            <div className="feature-icon"><Sparkles size={21} /></div>
            <h3>{title}</h3>
            <p className="feature-description">{description}</p>
          </article>
        ))}
      </div>
    </>
  );

  const renderAchievements = () => {
    const achievements = [
      {
        title: "First Steps",
        description: "Start your learning journey.",
        icon: GraduationCap,
        unlocked: true,
      },
      {
        title: "Curious Mind",
        description: "Explore your first course.",
        icon: BookOpen,
        unlocked: true,
      },
      {
        title: "Quest Starter",
        description: "Complete your first challenge.",
        icon: Target,
        unlocked: completedChallenges.length > 0,
      },
      {
        title: "XP Collector",
        description: "Earn 500 XP.",
        icon: Zap,
        unlocked: xp >= 500,
      },
      {
        title: "Consistent Learner",
        description: "Keep your learning streak alive.",
        icon: Flame,
        unlocked: false,
      },
      {
        title: "VIP Explorer",
        description: "Discover the VIP learning path.",
        icon: Crown,
        unlocked: false,
      },
    ];

    return (
      <>
        {renderHeading(
          "YOUR MILESTONES",
          "Achievements",
          "Every small win is a step toward something bigger.",
        )}

        <div className="achievement-summary">
          <div className="achievement-summary-icon"><Trophy size={25} /></div>
          <div>
            <span className="eyebrow">COLLECTION PROGRESS</span>
            <h2>{achievements.filter((item) => item.unlocked).length} of {achievements.length} unlocked</h2>
          </div>
        </div>

        <div className="achievement-grid">
          {achievements.map((achievement) => {
            const Icon = achievement.icon;

            return (
              <article
                className={`achievement-card ${achievement.unlocked ? "unlocked" : "locked"}`}
                key={achievement.title}
              >
                <div className="achievement-icon"><Icon size={27} /></div>
                {achievement.unlocked && (
                  <span className="achievement-unlocked"><Check size={13} /> UNLOCKED</span>
                )}
                <h3>{achievement.title}</h3>
                <p>{achievement.description}</p>
                {!achievement.unlocked && <LockKeyhole size={15} className="achievement-lock" />}
              </article>
            );
          })}
        </div>
      </>
    );
  };

  const renderVIP = () => (
    <>
      {renderHeading(
        "THE NEXT LEVEL",
        "Meet Nexiq VIP",
        "Explore the possibilities of a more advanced learning experience.",
      )}

      <section className="vip-page-hero">
        <div className="vip-page-icon"><Crown size={35} /></div>
        <span className="vip-label">NEXIQ / PREMIUM</span>
        <h2>More skills. More possibilities.</h2>
        <p>
          Explore exclusive learning paths and unlock new ways to grow.
          Membership and payments are not enabled in this demo.
        </p>
        <div className="vip-price">
          <strong>VIP</strong>
          <span>Premium learning experience</span>
        </div>
      </section>

      <div className="vip-benefits">
        {[
          ["Exclusive courses", "Explore advanced learning paths."],
          ["Deeper learning", "Build on your skills with focused lessons."],
          ["More challenges", "Discover additional ways to practice."],
          ["Learning milestones", "Keep track of your progress."],
        ].map(([title, description], index) => (
          <div className="benefit-row" key={title}>
            <div className="benefit-check"><Check size={17} /></div>
            <div className="benefit-copy">
              <h3>{title}</h3>
              <p>{description}</p>
            </div>
            <span className="benefit-number">0{index + 1}</span>
          </div>
        ))}
      </div>

      <div className="vip-note">
        <LockKeyhole size={17} />
        <p>
          This is a preview only. Real VIP access, subscriptions, and payments
          must be connected securely on the backend.
        </p>
      </div>
    </>
  );

  const renderProfile = () => (
    <>
      {renderHeading(
        "YOUR PERSONAL SPACE",
        "My Profile",
        "Your learning identity and progress, all in one place.",
      )}

      <section className="profile-card">
        <div className="profile-cover">
          <div className="profile-cover-orb" />
        </div>
        <div className="profile-details">
          <div className="profile-avatar"><UserRound size={33} /></div>
          <div className="profile-name-row">
            <div>
              <h2>Future Creator</h2>
              <p>Nexiq learner since today</p>
            </div>
            <span className="profile-level">LEVEL 4</span>
          </div>
          <div className="profile-stats">
            <div><strong>{xp}</strong><span>Total XP</span></div>
            <div><strong>{completedChallenges.length}</strong><span>Challenges</span></div>
            <div><strong>2</strong><span>Courses started</span></div>
          </div>
        </div>
      </section>

      <section className="page-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">YOUR LEARNING</span>
            <h2>Continue your journey</h2>
          </div>
        </div>
        <div className="course-grid">
          {courses.filter((course) => course.progress > 0).map(renderCourseCard)}
        </div>
      </section>

      <button className="settings-shortcut" onClick={() => navigate("settings")}>
        <Settings size={18} />
        <span><strong>Account preferences</strong><small>Manage your app settings</small></span>
        <ChevronRight size={18} />
      </button>
    </>
  );

  const renderSettings = () => (
    <>
      {renderHeading(
        "MAKE IT YOURS",
        "Settings",
        "Choose how Nexiq works for you.",
      )}

      <section className="settings-card">
        <div className="settings-row">
          <div className="settings-icon"><Globe size={20} /></div>
          <div className="settings-copy">
            <h3>App language</h3>
            <p>Choose your preferred language.</p>
          </div>
          <select
            className="language-select"
            value={language}
            onChange={(event) => setLanguage(event.target.value as Language)}
            aria-label="App language"
          >
            <option value="en">English</option>
            <option value="hy">Հայերեն</option>
          </select>
        </div>

        <div className="settings-row">
          <div className="settings-icon"><Sparkles size={20} /></div>
          <div className="settings-copy">
            <h3>Learning experience</h3>
            <p>Personalized recommendations are in demo mode.</p>
          </div>
          <span className="settings-tag">DEMO</span>
        </div>

        <div className="settings-row">
          <div className="settings-icon"><LockKeyhole size={20} /></div>
          <div className="settings-copy">
            <h3>Privacy and security</h3>
            <p>Authentication and account controls will be added later.</p>
          </div>
          <ChevronRight size={18} />
        </div>

        <div className="settings-row">
          <div className="settings-icon"><Bot size={20} /></div>
          <div className="settings-copy">
            <h3>AI Tutor</h3>
            <p>AI responses are currently simulated.</p>
          </div>
          <button className="text-link" onClick={() => navigate("aiTutor")}>
            Open <ArrowUpRight size={15} />
          </button>
        </div>
      </section>

      <div className="settings-footer">
        <span>NEXIQ</span>
        <span>Learn. Earn. Evolve.</span>
        <span>Frontend demo · v1.0</span>
      </div>
    </>
  );

  const renderCurrentPage = () => {
    if (selectedCourse) return renderCourseDetail();

    switch (page) {
      case "dashboard":
        return renderDashboard();
      case "courses":
        return renderCourses();
      case "challenges":
        return renderChallenges();
      case "aiTutor":
        return renderAITutor();
      case "achievements":
        return renderAchievements();
      case "vip":
        return renderVIP();
      case "profile":
        return renderProfile();
      case "settings":
        return renderSettings();
      default:
        return renderDashboard();
    }
  };

  const navigationItems: Page[] = [
    "dashboard",
    "courses",
    "challenges",
    "aiTutor",
    "achievements",
  ];

  return (
  <LocalizedUI language={language}>
    <div className="app-shell">
      {menuOpen && (
        <button
          className="menu-backdrop"
          aria-label="Close menu"
          onClick={() => setMenuOpen(false)}
        />
      )}

      <header className="topbar">
        <button
          className="brand"
          onClick={() => navigate("dashboard")}
          aria-label="Nexiq home"
        >
          <span className="brand-mark"><Zap size={23} fill="currentColor" /></span>
          <span className="brand-copy">
            <strong>NEXIQ<span>.</span></strong>
            <small>LEARN. EARN. EVOLVE.</small>
          </span>
        </button>

        <nav className="desktop-nav" aria-label="Main navigation">
          {navigationItems.slice(0, 4).map((item) => {
            const Icon = pageIcons[item];

            return (
              <button
                className={`nav-link ${page === item && !selectedCourse ? "active" : ""}`}
                key={item}
                onClick={() => navigate(item)}
              >
                <Icon size={16} />
                {pageLabels[item]}
              </button>
            );
          })}
        </nav>

        <div className="topbar-actions">
          <select
            className="language-select top-language"
            value={language}
            onChange={(event) => setLanguage(event.target.value as Language)}
            aria-label="Select language"
          >
            <option value="en">EN</option>
            <option value="hy">ՀՅ</option>
          </select>

          <button
            className={`top-vip-button ${page === "vip" ? "active" : ""}`}
            onClick={() => navigate("vip")}
          >
            <Crown size={15} /> VIP
          </button>

          <button
            className="avatar-button"
            onClick={() => navigate("profile")}
            aria-label="Open profile"
          >
            <UserRound size={18} />
          </button>

          <button
            className="menu-button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <aside className={`side-menu ${menuOpen ? "visible" : ""}`}>
        <div className="side-menu-heading">WORKSPACE</div>

        <nav className="menu-items" aria-label="Workspace">
          {navigationItems.map((item) => {
            const Icon = pageIcons[item];

            return (
              <button
                className={`menu-item ${page === item && !selectedCourse ? "active" : ""}`}
                key={item}
                onClick={() => navigate(item)}
              >
                <Icon size={18} />
                <span>{pageLabels[item]}</span>
                {item === "challenges" && <span className="menu-count">3</span>}
              </button>
            );
          })}
        </nav>

        <div className="side-menu-divider" />
        <div className="side-menu-heading">YOUR ACCOUNT</div>

        {(["profile", "settings"] as Page[]).map((item) => {
          const Icon = pageIcons[item];

          return (
            <button
              className={`menu-item ${page === item ? "active" : ""}`}
              key={item}
              onClick={() => navigate(item)}
            >
              <Icon size={18} />
              <span>{pageLabels[item]}</span>
            </button>
          );
        })}

        <button className="menu-vip" onClick={() => navigate("vip")}>
          <div className="menu-vip-icon"><Crown size={19} /></div>
          <div>
            <strong>Unlock Nexiq VIP</strong>
            <span>Take your skills further</span>
          </div>
          <ArrowUpRight size={17} />
        </button>

        <div className="menu-language">
          <span>{t("language").toUpperCase()}</span>
          <div className="language-toggle">
            <button
              className={language === "en" ? "selected" : ""}
              onClick={() => setLanguage("en")}
            >
              English
            </button>
            <button
              className={language === "hy" ? "selected" : ""}
              onClick={() => setLanguage("hy")}
            >
              Հայերեն
            </button>
          </div>
        </div>

        <div className="side-menu-bottom">
          <span className="brand-mark small"><Zap size={16} fill="currentColor" /></span>
          <div>
            <strong>NEXIQ</strong>
            <small>Learn. Earn. Evolve.</small>
          </div>
          <span className="version-tag">v1.0</span>
        </div>
      </aside>

      <main className="main-content">
        <div className="mobile-welcome">
          <span>{language === "hy" ? "ԲԱՐԻ ՎԵՐԱԴԱՐՁ" : "WELCOME BACK"}</span>
          <strong>
            {language === "hy" ? "Պատրա՞ստ ես զարգանալ" : "Ready to evolve?"}
          </strong>
        </div>

        {renderCurrentPage()}

        <footer className="footer">
          <div className="footer-brand">
            <span className="brand-mark small"><Zap size={15} fill="currentColor" /></span>
            <strong>NEXIQ</strong>
          </div>
          <span>Learn. Earn. Evolve.</span>
          <span>Keep growing, one step at a time.</span>
        </footer>
      </main>

      <nav className="mobile-bottom-nav" aria-label="Mobile navigation">
        {(
          ["dashboard", "courses", "challenges", "aiTutor", "profile"] as Page[]
        ).map((item) => {
          const Icon = pageIcons[item];

          return (
            <button
              key={item}
              className={`bottom-nav-item ${page === item && !selectedCourse ? "active" : ""}`}
              onClick={() => navigate(item)}
            >
              <Icon size={20} />
              <span>
                {item === "dashboard"
                  ? "Home"
                  : item === "aiTutor"
                    ? "AI Tutor"
                    : item === "challenges"
                      ? "Quests"
                      : item === "profile"
                        ? "Profile"
                        : "Courses"}
              </span>
            </button>
          );
        })}
      </nav>

      {notice && (
        <div className="toast" role="status">
          <Check size={18} />
          <span>{notice}</span>
          <button onClick={() => setNotice("")} aria-label="Dismiss notice">
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  </LocalizedUI>
  );
}

function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/lesson/:lessonId" element={<LessonPage />} />
        <Route path="/*" element={<App />} />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRouter;