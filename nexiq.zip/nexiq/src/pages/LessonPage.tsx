import { Link, useParams } from "react-router-dom";
import { lessons } from "../data/lessons";
import "./LessonPage.css";
import { completeLesson } from "../data/progress";
import { useNavigate } from "react-router-dom";

export default function LessonPage() {
  const navigate = useNavigate();  
  const { lessonId } = useParams();

  const lesson = lessons.find((item) => item.id === lessonId);

  if (!lesson) {
    return (
      <main className="lesson-page">
        <h1>Դասը չի գտնվել</h1>
        <Link to="/">Վերադառնալ գլխավոր էջ</Link>
      </main>
    );
  }

  return (
    <main className="lesson-page">
      <Link to={`/course/${lesson.courseId}`}>
        ← Վերադառնալ դասընթացին
      </Link>

      <article className="lesson-page-card">
        {lesson.isVip && (
          <span className="lesson-vip-label">VIP</span>
        )}

        <h1>{lesson.title}</h1>

        <p>{lesson.content}</p>

        {lesson.isVip ? (
          <p>Այս դասը նախատեսված է VIP օգտատերերի համար։</p>
        ) : (
          <button
            type="button"
            onClick={() => {
            completeLesson(lesson.id);
            navigate(`/course/${lesson.courseId}`);
            }}
          >
            Ավարտել դասը
          </button>
        )}
      </article>
    </main>
  );
}
