import { Link, useParams } from "react-router-dom";
import { lessons } from "../data/lessons";
import "./LessonPage.css";
import { completeLesson, getCompletedLessons, readStoredJson } from "../data/progress";
import { useNavigate } from "react-router-dom";

export default function LessonPage() {
  const navigate = useNavigate();
  const { lessonId } = useParams();
  const lesson = lessons.find((item) => item.id === lessonId);
  const savedLanguage = readStoredJson<unknown>("nexiq-language", "hy");
  const language = savedLanguage === "en" ? "en" : "hy";

  if (!lesson) {
    return (
      <main className="lesson-page">
        <h1>{language === "hy" ? "Դասը չի գտնվել" : "Lesson not found"}</h1>
        <Link to="/">{language === "hy" ? "Վերադառնալ գլխավոր էջ" : "Return to dashboard"}</Link>
      </main>
    );
  }

  const completed = getCompletedLessons().includes(lesson.id);

  return (
    <main className="lesson-page">
      <Link to="/">
        ← {language === "hy" ? "Վերադառնալ Nexiq" : "Back to Nexiq"}
      </Link>

      <article className="lesson-page-card">
        {lesson.isVip && (
          <>
            <span className="lesson-vip-label">VIP</span>
            <p>{language === "hy"
              ? "Այս դասը VIP բովանդակություն է։ Վճարումները և VIP մուտքը ցուցադրական տարբերակում միացված չեն։"
              : "This lesson is VIP content. Payments and VIP access are not enabled in this demo."}</p>
          </>
        )}

        <h1>{lesson.title[language]}</h1>

        {!lesson.isVip && <p>{lesson.content[language]}</p>}

        {lesson.isVip ? (
          <Link to="/">{language === "hy" ? "Դիտել Nexiq VIP-ը" : "Explore Nexiq VIP"}</Link>
        ) : (
          <button
            type="button"
            onClick={() => {
              if (!completed) completeLesson(lesson.id);
              navigate("/");
            }}
          >
            {completed
              ? language === "hy" ? "Վերադառնալ դասընթացներին" : "Return to courses"
              : language === "hy" ? "Ավարտել դասը" : "Complete lesson"}
          </button>
        )}
      </article>
    </main>
  );
}
