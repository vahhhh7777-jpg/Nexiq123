# Nexiq Learning Platform

Nexiq is a React, TypeScript, and Vite learning platform demo for programming, AI, UI/UX design, digital marketing, video production, and web development. The app includes a dashboard, course and lesson views, interactive practice challenges, a clearly labeled local AI-tutor demo, achievements, VIP preview, profile, and settings.

## Run locally

Requirements: Node.js 20.19+ (or 22.12+) and npm.

```bash
npm ci
npm run dev
```

Open the local URL printed by Vite. To verify a production build:

```bash
npm run build
npm run preview
```

Run the configured linter with:

```bash
npm run lint
```

## Local data and feature limits

- Lesson completions, challenge completions, language, and the editable profile are saved in the current browser's `localStorage`. They are not account-backed or synchronized between devices.
- Progress and XP are calculated from completed lessons and correctly answered challenges. Clearing browser storage resets local progress.
- The AI Tutor is a local demo response, not a connected model. No API key or backend is required.
- VIP lessons are locked in the demo. Payments, subscriptions, and VIP access are not implemented.
- There is no sign-in, cloud database, or cross-device sync.

## Project layout

- `src/App.tsx` — app navigation and page components.
- `src/data/lessons.ts` — bilingual course and lesson content.
- `src/data/progress.ts` — guarded browser storage and legacy progress migration.
- `src/pages/LessonPage.tsx` — direct lesson route and VIP access guard.
- `src/translations.ts` — shared Armenian and English interface strings.
- `src/index.css` and `src/App.css` — styles.

No environment variables are needed for the local demo, so no `.env` file is required.
